#!/usr/bin/env python3
"""
Admin Dashboard for Telegram Shop Bot
Web-based admin interface for managing the bot
"""
import os
import logging
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from wtforms import StringField, FloatField, IntegerField, TextAreaField, SelectField, SubmitField, BooleanField
from wtforms.validators import DataRequired, NumberRange, Length
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import json
import os
import asyncio
from threading import Thread
import requests
from data.database import Database
from data.models import User, Order
from bot.commands import BotCommands
from config import Config
from data.admin_integration import integration

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'admin-dashboard-secret-key')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_pre_ping': True,
    'pool_recycle': 300,
    'pool_timeout': 20,
    'pool_size': 5,
    'max_overflow': 10,
    'connect_args': {
        'connect_timeout': 10,
        'keepalives_idle': 600,
        'keepalives_interval': 30,
        'keepalives_count': 3
    }
}

# Initialize database
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Initialize bot database
bot_db = Database()
bot_commands = BotCommands(bot_db)

# Database Models for Admin Dashboard
class Admin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    telegram_id = db.Column(db.BigInteger, unique=True, nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class ProductCategory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    description = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class MeasurementUnit(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)
    symbol = db.Column(db.String(10), nullable=False)
    is_active = db.Column(db.Boolean, default=True)

class PaymentMethod(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    type = db.Column(db.String(50), nullable=False)  # 'crypto', 'traditional', 'digital'
    wallet_address = db.Column(db.String(200))
    qr_code_url = db.Column(db.String(500))
    instructions = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class BroadcastMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    image_url = db.Column(db.String(500))
    sent_by = db.Column(db.Integer, db.ForeignKey('admin.id'), nullable=False)
    sent_at = db.Column(db.DateTime, default=datetime.utcnow)
    recipient_count = db.Column(db.Integer, default=0)
    status = db.Column(db.String(20), default='pending')  # pending, sent, failed

class BotSettings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    setting_key = db.Column(db.String(100), unique=True, nullable=False)
    setting_value = db.Column(db.Text, nullable=False)
    description = db.Column(db.Text)
    updated_by = db.Column(db.Integer, db.ForeignKey('admin.id'), nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)



class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    description = db.Column(db.Text)
    stock = db.Column(db.Integer, default=0)
    category_id = db.Column(db.Integer, db.ForeignKey('product_category.id'))
    category = db.relationship('ProductCategory', backref='products')
    measurement_unit_id = db.Column(db.Integer, db.ForeignKey('measurement_unit.id'))
    measurement_unit = db.relationship('MeasurementUnit', backref='products')
    image_url = db.Column(db.String(500))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class BotOperator(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    telegram_username = db.Column(db.String(100))
    telegram_id = db.Column(db.BigInteger)
    email = db.Column(db.String(200))
    phone = db.Column(db.String(20))
    is_active = db.Column(db.Boolean, default=True)
    working_hours = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# Forms
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = StringField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class ProductForm(FlaskForm):
    name = StringField('Product Name', validators=[DataRequired(), Length(max=100)])
    price = FloatField('Price', validators=[DataRequired(), NumberRange(min=0.01)])
    description = TextAreaField('Description', validators=[Length(max=500)])
    category = SelectField('Category', coerce=int)
    measurement_unit = SelectField('Measurement Unit', coerce=int)
    stock = IntegerField('Stock', validators=[DataRequired(), NumberRange(min=0)])
    image_url = StringField('Image URL', validators=[Length(max=500)])
    is_active = BooleanField('Active')
    submit = SubmitField('Save Product')

class CategoryForm(FlaskForm):
    name = StringField('Category Name', validators=[DataRequired(), Length(max=100)])
    description = TextAreaField('Description')
    is_active = BooleanField('Active', default=True)
    submit = SubmitField('Save Category')

class MeasurementUnitForm(FlaskForm):
    name = StringField('Unit Name', validators=[DataRequired(), Length(max=50)])
    symbol = StringField('Symbol', validators=[DataRequired(), Length(max=10)])
    is_active = BooleanField('Active', default=True)
    submit = SubmitField('Save Unit')

class PaymentMethodForm(FlaskForm):
    name = StringField('Payment Method Name', validators=[DataRequired(), Length(max=100)])
    type = SelectField('Type', choices=[('crypto', 'Cryptocurrency'), ('traditional', 'Traditional'), ('digital', 'Digital Wallet')])
    wallet_address = StringField('Wallet Address/Account', validators=[Length(max=200)])
    qr_code_url = StringField('QR Code URL', validators=[Length(max=500)])
    instructions = TextAreaField('Instructions')
    is_active = BooleanField('Active', default=True)
    submit = SubmitField('Save Payment Method')

class BroadcastForm(FlaskForm):
    title = StringField('Broadcast Title', validators=[DataRequired(), Length(max=200)])
    message = TextAreaField('Message', validators=[DataRequired()])
    image_url = StringField('Image URL (optional)', validators=[Length(max=500)])
    submit = SubmitField('Send Broadcast')

class BotSettingsForm(FlaskForm):
    welcome_message = TextAreaField('Welcome Message', validators=[DataRequired()], render_kw={"rows": 6})
    submit = SubmitField('Save Settings')



class OperatorForm(FlaskForm):
    name = StringField('Operator Name', validators=[DataRequired(), Length(max=100)])
    telegram_username = StringField('Telegram Username', validators=[Length(max=100)])
    telegram_id = StringField('Telegram ID', validators=[Length(max=20)])
    email = StringField('Email', validators=[Length(max=200)])
    phone = StringField('Phone', validators=[Length(max=20)])
    working_hours = StringField('Working Hours', validators=[Length(max=200)])
    is_active = BooleanField('Active', default=True)
    submit = SubmitField('Save Operator')

# Helper functions
def login_required(f):
    def decorated_function(*args, **kwargs):
        if 'admin_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

def send_broadcast_to_users(title, message, image_url=None):
    """Send broadcast message to all bot users"""
    try:
        # Get all users from bot database
        users_data = bot_db.load_json(os.path.join('data', 'users.json'))
        
        if not users_data:
            logger.warning("No users found for broadcast")
            return 0
        
        # Format the broadcast message
        broadcast_text = f"📢 {title}\n\n{message}"
        
        # Import telegram bot components
        import asyncio
        from telegram import Bot
        from telegram.error import TelegramError
        
        # Initialize bot
        bot = Bot(token=os.environ.get('BOT_TOKEN'))
        
        # Send messages to all users
        success_count = 0
        
        async def send_to_user(user_id):
            try:
                if image_url and image_url.strip():
                    # Send photo with caption
                    await bot.send_photo(
                        chat_id=user_id, 
                        photo=image_url.strip(),
                        caption=broadcast_text
                    )
                else:
                    # Send text message only
                    await bot.send_message(chat_id=user_id, text=broadcast_text)
                return True
            except TelegramError as e:
                logger.error(f"Failed to send broadcast to user {user_id}: {e}")
                return False
        
        async def send_all_broadcasts():
            tasks = []
            for user_id in users_data.keys():
                if user_id.isdigit():  # Valid user ID
                    tasks.append(send_to_user(int(user_id)))
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            return sum(1 for result in results if result is True)
        
        # Run the broadcast in a new event loop
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            success_count = loop.run_until_complete(send_all_broadcasts())
        finally:
            loop.close()
        
        logger.info(f"Broadcast sent to {success_count} users")
        return success_count
        
    except Exception as e:
        logger.error(f"Error sending broadcast: {e}")
        return 0

def get_bot_statistics():
    """Get bot statistics from the JSON database"""
    try:
        users = bot_db.get_all_users()
        products = bot_db.get_products()
        orders = bot_db.get_all_orders()
        
        return {
            'total_users': len(users),
            'total_products': len(products),
            'total_orders': len(orders),
            'pending_orders': len([o for o in orders if o.status == 'pending']),
            'completed_orders': len([o for o in orders if o.status == 'completed']),
            'total_revenue': sum(o.total for o in orders if o.status == 'completed')
        }
    except Exception as e:
        logger.error(f"Error getting bot statistics: {e}")
        return {
            'total_users': 0,
            'total_products': 0,
            'total_orders': 0,
            'pending_orders': 0,
            'completed_orders': 0,
            'total_revenue': 0
        }

# Routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        admin = Admin.query.filter_by(username=form.username.data).first()
        if admin and admin.check_password(form.password.data) and admin.is_active:
            session['admin_id'] = admin.id
            session['admin_username'] = admin.username
            return redirect(url_for('dashboard'))
        flash('Invalid username or password', 'error')
    return render_template('admin/login.html', form=form)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/')
@login_required
def dashboard():
    stats = get_bot_statistics()
    recent_orders = bot_db.get_all_orders()[-10:]  # Last 10 orders
    categories = ProductCategory.query.filter_by(is_active=True).all()
    payment_methods = PaymentMethod.query.filter_by(is_active=True).all()
    
    return render_template('admin/dashboard.html', 
                         stats=stats, 
                         recent_orders=recent_orders,
                         categories=categories,
                         payment_methods=payment_methods)

@app.route('/products')
@login_required
def products():
    bot_products = bot_db.get_products()
    categories = ProductCategory.query.all()
    units = MeasurementUnit.query.filter_by(is_active=True).all()
    
    return render_template('admin/products.html', 
                         products=bot_products,
                         categories=categories,
                         units=units)

@app.route('/products/add', methods=['GET', 'POST'])
@login_required
def add_product():
    form = ProductForm()
    form.category.choices = [(c.id, c.name) for c in ProductCategory.query.filter_by(is_active=True).all()]
    form.measurement_unit.choices = [(u.id, u.name) for u in MeasurementUnit.query.filter_by(is_active=True).all()]
    
    if form.validate_on_submit():
        try:
            # Get category and unit names
            category = ProductCategory.query.get(form.category.data)
            unit = MeasurementUnit.query.get(form.measurement_unit.data)
            
            # Create new product for admin database
            product = Product(
                name=form.name.data,
                price=form.price.data,
                description=form.description.data,
                category_id=form.category.data,
                measurement_unit_id=form.measurement_unit.data,
                stock=form.stock.data,
                image_url=form.image_url.data or "",
                is_active=form.is_active.data
            )
            
            db.session.add(product)
            db.session.commit()
            
            # Also add to bot database
            bot_product_data = {
                'id': str(product.id),
                'name': product.name,
                'price': product.price,
                'description': product.description or '',
                'category': category.name if category else 'General',
                'stock': product.stock,
                'image_url': product.image_url or '',
                'is_active': product.is_active,
                'rating': 0.0,
                'rating_count': 0
            }
            
            # Save to bot's JSON database
            products_file = os.path.join('data', 'products.json')
            try:
                with open(products_file, 'r') as f:
                    bot_products = json.load(f)
            except (FileNotFoundError, json.JSONDecodeError):
                bot_products = {}
            
            bot_products[str(product.id)] = bot_product_data
            
            with open(products_file, 'w') as f:
                json.dump(bot_products, f, indent=2)
            
            if True:  # Always true since we're handling it ourselves
                flash('Product added successfully!', 'success')
                return redirect(url_for('products'))
            else:
                flash('Error adding product', 'error')
        except Exception as e:
            logger.error(f"Error adding product: {e}")
            flash('Error adding product', 'error')
    
    return render_template('admin/product_form.html', form=form, title='Add Product')

@app.route('/products/edit/<int:product_id>', methods=['GET', 'POST'])
@login_required
def edit_product(product_id):
    product = bot_db.get_product(product_id)
    if not product:
        flash('Product not found', 'error')
        return redirect(url_for('products'))
    
    form = ProductForm()
    form.category.choices = [(c.id, c.name) for c in ProductCategory.query.filter_by(is_active=True).all()]
    form.measurement_unit.choices = [(u.id, u.name) for u in MeasurementUnit.query.filter_by(is_active=True).all()]
    
    if form.validate_on_submit():
        try:
            category = ProductCategory.query.get(form.category.data)
            
            # Update product
            product.name = form.name.data
            product.price = form.price.data
            product.description = form.description.data
            product.category = category.name if category else "General"
            product.stock = form.stock.data
            product.image_url = form.image_url.data or ""
            
            if bot_db.save_product(product):
                flash('Product updated successfully!', 'success')
                return redirect(url_for('products'))
            else:
                flash('Error updating product', 'error')
        except Exception as e:
            logger.error(f"Error updating product: {e}")
            flash('Error updating product', 'error')
    
    # Pre-populate form
    form.name.data = product.name
    form.price.data = product.price
    form.description.data = product.description
    form.stock.data = product.stock
    form.image_url.data = product.image_url
    
    return render_template('admin/product_form.html', form=form, title='Edit Product')

@app.route('/categories')
@login_required
def categories():
    categories = ProductCategory.query.all()
    return render_template('admin/categories.html', categories=categories)

@app.route('/categories/add', methods=['GET', 'POST'])
@login_required
def add_category():
    form = CategoryForm()
    if form.validate_on_submit():
        category = ProductCategory(
            name=form.name.data,
            description=form.description.data,
            is_active=form.is_active.data
        )
        db.session.add(category)
        db.session.commit()
        flash('Category added successfully!', 'success')
        return redirect(url_for('categories'))
    
    return render_template('admin/category_form.html', form=form, title='Add Category')

@app.route('/categories/edit/<int:category_id>', methods=['GET', 'POST'])
@login_required
def edit_category(category_id):
    category = ProductCategory.query.get_or_404(category_id)
    form = CategoryForm(obj=category)
    
    if form.validate_on_submit():
        form.populate_obj(category)
        db.session.commit()
        flash('Category updated successfully!', 'success')
        return redirect(url_for('categories'))
    
    return render_template('admin/category_form.html', form=form, title='Edit Category')

@app.route('/measurement-units')
@login_required
def measurement_units():
    units = MeasurementUnit.query.all()
    return render_template('admin/measurement_units.html', units=units)

@app.route('/measurement-units/add', methods=['GET', 'POST'])
@login_required
def add_measurement_unit():
    form = MeasurementUnitForm()
    if form.validate_on_submit():
        unit = MeasurementUnit(
            name=form.name.data,
            symbol=form.symbol.data,
            is_active=form.is_active.data
        )
        db.session.add(unit)
        db.session.commit()
        flash('Measurement unit added successfully!', 'success')
        return redirect(url_for('measurement_units'))
    
    return render_template('admin/measurement_unit_form.html', form=form, title='Add Measurement Unit')

@app.route('/payment-methods')
@login_required
def payment_methods():
    methods = PaymentMethod.query.all()
    return render_template('admin/payment_methods.html', methods=methods)

@app.route('/payment-methods/add', methods=['GET', 'POST'])
@login_required
def add_payment_method():
    form = PaymentMethodForm()
    if form.validate_on_submit():
        method = PaymentMethod(
            name=form.name.data,
            type=form.type.data,
            wallet_address=form.wallet_address.data,
            qr_code_url=form.qr_code_url.data,
            instructions=form.instructions.data,
            is_active=form.is_active.data
        )
        db.session.add(method)
        db.session.commit()
        flash('Payment method added successfully!', 'success')
        return redirect(url_for('payment_methods'))
    
    return render_template('admin/payment_method_form.html', form=form, title='Add Payment Method')

@app.route('/broadcast')
@login_required
def broadcast():
    broadcasts = BroadcastMessage.query.order_by(BroadcastMessage.sent_at.desc()).limit(20).all()
    return render_template('admin/broadcast.html', broadcasts=broadcasts)

@app.route('/broadcast/send', methods=['GET', 'POST'])
@login_required
def send_broadcast():
    form = BroadcastForm()
    if form.validate_on_submit():
        broadcast = BroadcastMessage(
            title=form.title.data,
            message=form.message.data,
            image_url=form.image_url.data,
            sent_by=session['admin_id']
        )
        db.session.add(broadcast)
        db.session.commit()
        
        # Send broadcast to all users
        success_count = send_broadcast_to_users(form.title.data, form.message.data, form.image_url.data)
        
        # Update broadcast record with results
        broadcast.recipient_count = success_count
        broadcast.status = 'sent' if success_count > 0 else 'failed'
        db.session.commit()
        
        if success_count > 0:
            flash(f'Broadcast sent successfully to {success_count} users!', 'success')
        else:
            flash('Broadcast failed - no users to send to or bot unavailable', 'error')
        return redirect(url_for('broadcast'))
    
    return render_template('admin/broadcast_form.html', form=form)



@app.route('/operators')
@login_required
def operators():
    operators = BotOperator.query.all()
    return render_template('admin/operators.html', operators=operators)

@app.route('/operators/add', methods=['GET', 'POST'])
@login_required
def add_operator():
    form = OperatorForm()
    if form.validate_on_submit():
        # Convert telegram_id to integer if provided
        telegram_id = None
        if form.telegram_id.data:
            try:
                telegram_id = int(form.telegram_id.data)
            except ValueError:
                flash('Invalid Telegram ID format', 'error')
                return render_template('admin/operator_form.html', form=form, title='Add Operator')
        
        operator = BotOperator(
            name=form.name.data,
            telegram_username=form.telegram_username.data,
            telegram_id=telegram_id,
            email=form.email.data,
            phone=form.phone.data,
            working_hours=form.working_hours.data,
            is_active=form.is_active.data
        )
        db.session.add(operator)
        db.session.commit()
        flash('Operator added successfully!', 'success')
        return redirect(url_for('operators'))
    
    return render_template('admin/operator_form.html', form=form, title='Add Operator')

@app.route('/orders')
@login_required
def orders():
    orders = bot_db.get_all_orders()
    return render_template('admin/orders.html', orders=orders)

@app.route('/bot_settings', methods=['GET', 'POST'])
@login_required
def bot_settings():
    """Manage bot settings"""
    form = BotSettingsForm()
    
    # Get current welcome message
    current_welcome = BotSettings.query.filter_by(setting_key='welcome_message').first()
    
    if form.validate_on_submit():
        # Update or create welcome message setting
        if current_welcome:
            current_welcome.setting_value = form.welcome_message.data
            current_welcome.updated_by = session['admin_id']
            current_welcome.updated_at = datetime.utcnow()
        else:
            current_welcome = BotSettings(
                setting_key='welcome_message',
                setting_value=form.welcome_message.data,
                description='Bot welcome message displayed to new users',
                updated_by=session['admin_id']
            )
            db.session.add(current_welcome)
        
        db.session.commit()
        flash('Bot settings updated successfully!', 'success')
        return redirect(url_for('bot_settings'))
    
    # Pre-populate form with current values
    if current_welcome:
        form.welcome_message.data = current_welcome.setting_value
    else:
        # Default welcome message
        form.welcome_message.data = """🛍️ Welcome to the Vanishing Shop Bot!

This bot features self-destructing messages for enhanced privacy.
Use /help to see available commands."""
    
    return render_template('admin/bot_settings.html', form=form, current_welcome=current_welcome)

@app.route('/api/stats')
@login_required
def api_stats():
    return jsonify(get_bot_statistics())

@app.route('/api/sync-to-bot', methods=['POST'])
@login_required
def sync_to_bot():
    """Sync admin data to bot database"""
    try:
        # Get all data from admin database
        admin_data = {}
        
        # Get products with proper model handling
        products = Product.query.all()
        admin_data['products'] = []
        for p in products:
            category_name = 'General'
            if p.category:
                category_name = p.category.name
            admin_data['products'].append({
                'id': p.id,
                'name': p.name,
                'price': p.price,
                'description': p.description or '',
                'stock': p.stock,
                'category': category_name,
                'image_url': p.image_url or '',
                'is_active': p.is_active
            })
        
        # Get categories
        categories = ProductCategory.query.all()
        admin_data['categories'] = [{
            'id': c.id,
            'name': c.name,
            'description': c.description or '',
            'is_active': c.is_active
        } for c in categories]
        
        # Get payment methods
        payment_methods = PaymentMethod.query.all()
        admin_data['payment_methods'] = [{
            'id': p.id,
            'name': p.name,
            'type': p.type,
            'wallet_address': p.wallet_address or '',
            'qr_code_url': p.qr_code_url or '',
            'instructions': p.instructions or '',
            'is_active': p.is_active
        } for p in payment_methods]
        

        
        # Get operators
        operators = BotOperator.query.all()
        admin_data['operators'] = [{
            'id': o.id,
            'name': o.name,
            'telegram_username': o.telegram_username or '',
            'telegram_id': o.telegram_id,
            'email': o.email or '',
            'phone': o.phone or '',
            'working_hours': o.working_hours or '',
            'is_active': o.is_active
        } for o in operators]
        
        # Get bot settings
        bot_settings = BotSettings.query.all()
        admin_data['bot_settings'] = {}
        for setting in bot_settings:
            admin_data['bot_settings'][setting.setting_key] = setting.setting_value
        
        # Perform sync
        results = integration.full_sync_from_admin(admin_data)
        
        return jsonify({
            'success': True,
            'message': 'Data synced to bot successfully',
            'results': results
        })
        
    except Exception as e:
        logger.error(f"Error syncing to bot: {e}")
        return jsonify({
            'success': False,
            'message': f'Error syncing to bot: {str(e)}'
        }), 500

@app.route('/api/bot-stats')
@login_required
def bot_stats():
    """Get bot statistics"""
    try:
        stats = integration.get_bot_stats()
        return jsonify(stats)
    except Exception as e:
        logger.error(f"Error getting bot stats: {e}")
        return jsonify({'error': str(e)}), 500

def create_default_admin():
    """Create default admin user"""
    admin = Admin.query.filter_by(username='admin').first()
    if not admin:
        admin = Admin(username='admin', telegram_id=0)
        admin.set_password('admin123')
        db.session.add(admin)
        db.session.commit()
        print("Default admin created: username=admin, password=admin123")

def create_default_data():
    """Create default categories, units, and payment methods"""
    # Default categories
    if not ProductCategory.query.first():
        categories = [
            {'name': 'Acetate Powder', 'description': 'Acetate-based compounds'},
            {'name': 'Enanthate Powder', 'description': 'Enanthate-based compounds'},
            {'name': 'Cypionate Powder', 'description': 'Cypionate-based compounds'},
            {'name': 'Propionate Powder', 'description': 'Propionate-based compounds'},
            {'name': 'Undecanoate Powder', 'description': 'Undecanoate-based compounds'},
            {'name': 'Capsules', 'description': 'Ready-to-use capsules'},
            {'name': 'Tablets', 'description': 'Compressed tablets'},
            {'name': 'Liquids', 'description': 'Liquid formulations'},
            {'name': 'Accessories', 'description': 'Related accessories'}
        ]
        
        for cat_data in categories:
            category = ProductCategory(**cat_data)
            db.session.add(category)
    
    # Default measurement units
    if not MeasurementUnit.query.first():
        units = [
            {'name': 'Grams', 'symbol': 'g'},
            {'name': 'Kilograms', 'symbol': 'kg'},
            {'name': 'Milligrams', 'symbol': 'mg'},
            {'name': 'Pieces', 'symbol': 'pcs'},
            {'name': 'Bottles', 'symbol': 'btl'},
            {'name': 'Vials', 'symbol': 'vial'},
            {'name': 'Capsules', 'symbol': 'caps'},
            {'name': 'Tablets', 'symbol': 'tabs'},
            {'name': 'Milliliters', 'symbol': 'ml'},
            {'name': 'Liters', 'symbol': 'L'}
        ]
        
        for unit_data in units:
            unit = MeasurementUnit(**unit_data)
            db.session.add(unit)
    
    # Default payment methods
    if not PaymentMethod.query.first():
        methods = [
            {
                'name': 'Bitcoin',
                'type': 'crypto',
                'wallet_address': 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq',
                'qr_code_url': 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq',
                'instructions': 'Send Bitcoin to the provided wallet address and contact support with transaction ID.'
            },
            {
                'name': 'Bank Transfer',
                'type': 'traditional',
                'wallet_address': 'Account: 1234567890, Bank: Example Bank',
                'instructions': 'Transfer to the provided bank account and send proof of payment.'
            },
            {
                'name': 'PayPal',
                'type': 'digital',
                'wallet_address': 'payments@shopbot.com',
                'instructions': 'Send payment to the provided PayPal email address.'
            }
        ]
        
        for method_data in methods:
            method = PaymentMethod(**method_data)
            db.session.add(method)
    
    db.session.commit()

@app.route('/api/payment-method/<int:payment_id>')
@login_required
def get_payment_method(payment_id):
    """Get payment method details for API"""
    try:
        method = PaymentMethod.query.get_or_404(payment_id)
        return jsonify({
            'id': method.id,
            'name': method.name,
            'type': method.type,
            'wallet_address': method.wallet_address,
            'qr_code_url': method.qr_code_url,
            'instructions': method.instructions,
            'is_active': method.is_active,
            'created_at': method.created_at.isoformat()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/payment-method/<int:payment_id>', methods=['DELETE'])
@login_required
def delete_payment_method_api(payment_id):
    """Delete payment method via API"""
    try:
        method = PaymentMethod.query.get_or_404(payment_id)
        db.session.delete(method)
        db.session.commit()
        
        # Sync to bot after deletion
        try:
            sync_to_bot()
        except Exception as sync_error:
            print(f"Warning: Failed to sync to bot after deletion: {sync_error}")
        
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/payment-methods/edit/<int:payment_id>')
@login_required
def edit_payment_method(payment_id):
    """Edit payment method form"""
    method = PaymentMethod.query.get_or_404(payment_id)
    form = PaymentMethodForm(obj=method)
    
    if form.validate_on_submit():
        method.name = form.name.data
        method.type = form.type.data
        method.wallet_address = form.wallet_address.data
        method.qr_code_url = form.qr_code_url.data
        method.instructions = form.instructions.data
        method.is_active = form.is_active.data
        
        db.session.commit()
        flash('Payment method updated successfully!', 'success')
        
        # Sync to bot
        try:
            sync_to_bot()
        except Exception as e:
            flash(f'Warning: Failed to sync to bot: {str(e)}', 'warning')
        
        return redirect(url_for('payment_methods'))
    
    return render_template('admin/payment_method_form.html', form=form, 
                         title='Edit Payment Method', method=method)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        create_default_admin()
        create_default_data()
    
    app.run(host='0.0.0.0', port=5000, debug=True)