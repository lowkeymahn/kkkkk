"""
Configuration settings for the Telegram shop bot
"""
import os
from typing import Dict, Any

class Config:
    """Configuration class for the bot"""
    
    # Bot configuration
    BOT_TOKEN: str = os.getenv('BOT_TOKEN', 'YOUR_BOT_TOKEN_HERE')
    
    # Database configuration
    DATA_DIRECTORY: str = os.getenv('DATA_DIRECTORY', 'data')
    
    # Vanishing messages configuration
    DEFAULT_VANISH_TIME: int = int(os.getenv('DEFAULT_VANISH_TIME', '300'))  # 5 minutes
    MAX_VANISH_TIME: int = int(os.getenv('MAX_VANISH_TIME', '3600'))  # 1 hour
    MIN_VANISH_TIME: int = int(os.getenv('MIN_VANISH_TIME', '10'))  # 10 seconds
    
    # Shop configuration
    CURRENCY_SYMBOL: str = os.getenv('CURRENCY_SYMBOL', '$')
    MAX_CART_ITEMS: int = int(os.getenv('MAX_CART_ITEMS', '50'))
    MAX_WISHLIST_ITEMS: int = int(os.getenv('MAX_WISHLIST_ITEMS', '100'))
    
    # Order configuration
    ORDER_STATUSES: Dict[str, str] = {
        'pending': 'Pending',
        'confirmed': 'Confirmed',
        'shipped': 'Shipped',
        'completed': 'Completed',
        'cancelled': 'Cancelled'
    }
    
    # Admin configuration
    SUPER_ADMIN_ID: int = int(os.getenv('SUPER_ADMIN_ID', '0'))
    
    # API configuration
    API_TIMEOUT: int = int(os.getenv('API_TIMEOUT', '30'))
    MAX_RETRIES: int = int(os.getenv('MAX_RETRIES', '3'))
    
    # Security configuration
    RATE_LIMIT_REQUESTS: int = int(os.getenv('RATE_LIMIT_REQUESTS', '30'))
    RATE_LIMIT_WINDOW: int = int(os.getenv('RATE_LIMIT_WINDOW', '60'))  # seconds
    
    # Logging configuration
    LOG_LEVEL: str = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FILE: str = os.getenv('LOG_FILE', 'bot.log')
    
    # Feature flags
    ENABLE_RATINGS: bool = os.getenv('ENABLE_RATINGS', 'true').lower() == 'true'
    ENABLE_WISHLIST: bool = os.getenv('ENABLE_WISHLIST', 'true').lower() == 'true'
    ENABLE_VANISHING: bool = os.getenv('ENABLE_VANISHING', 'true').lower() == 'true'
    ENABLE_ADMIN_PANEL: bool = os.getenv('ENABLE_ADMIN_PANEL', 'true').lower() == 'true'
    
    # Message templates
    MESSAGES: Dict[str, str] = {
        'welcome': """🛍️ Welcome to the Vanishing Shop Bot!
        
This bot features self-destructing messages for enhanced privacy.
Use /help to see available commands.""",
        
        'help': """🔧 Available Commands:
        
🛍️ Shopping:
/listings - Browse products
/cart - View cart
/wishlist - Manage wishlist
/orders - View orders

⭐ Rating:
/rating - Rate products

👨‍💼 Support:
/operator - Contact support

⚙️ Settings:
/vanish - Configure message deletion""",
        
        'error': "❌ An error occurred. Please try again.",
        'success': "✅ Operation completed successfully!",
        'not_found': "❓ Item not found.",
        'access_denied': "🚫 Access denied.",
        'empty_cart': "🛒 Your cart is empty.",
        'empty_wishlist': "💝 Your wishlist is empty.",
        'no_orders': "📦 No orders found.",
        'no_products': "📦 No products available."
    }
    
    # Validation rules
    VALIDATION: Dict[str, Any] = {
        'product_name_max_length': 100,
        'product_description_max_length': 500,
        'max_rating': 5,
        'min_rating': 1,
        'max_price': 999999.99,
        'min_price': 0.01,
        'max_stock': 10000,
        'min_stock': 0
    }
    
    # UI configuration
    UI_CONFIG: Dict[str, Any] = {
        'products_per_page': 10,
        'orders_per_page': 5,
        'max_inline_buttons': 8,
        'button_text_max_length': 30
    }
    
    @classmethod
    def get_bot_token(cls) -> str:
        """Get bot token with validation"""
        token = cls.BOT_TOKEN
        if not token or token == 'YOUR_BOT_TOKEN_HERE':
            raise ValueError("Bot token not configured. Please set BOT_TOKEN environment variable.")
        return token
        
    @classmethod
    def get_vanish_time_options(cls) -> Dict[str, int]:
        """Get available vanish time options"""
        return {
            "⚡ 30 seconds": 30,
            "🕐 1 minute": 60,
            "🕐 5 minutes": 300,
            "🕐 10 minutes": 600,
            "🕐 1 hour": 3600,
            "♾️ Never": 0
        }
        
    @classmethod
    def validate_vanish_time(cls, seconds: int) -> bool:
        """Validate vanish time value"""
        return (seconds == 0 or 
                (cls.MIN_VANISH_TIME <= seconds <= cls.MAX_VANISH_TIME))
        
    @classmethod
    def get_status_emoji(cls, status: str) -> str:
        """Get emoji for order status"""
        emojis = {
            'pending': '⏳',
            'confirmed': '✅',
            'shipped': '🚚',
            'completed': '🎉',
            'cancelled': '❌'
        }
        return emojis.get(status, '❓')
        
    @classmethod
    def format_price(cls, price: float) -> str:
        """Format price with currency symbol"""
        return f"{cls.CURRENCY_SYMBOL}{price:.2f}"
        
    @classmethod
    def validate_price(cls, price: float) -> bool:
        """Validate price value"""
        return cls.VALIDATION['min_price'] <= price <= cls.VALIDATION['max_price']
        
    @classmethod
    def validate_stock(cls, stock: int) -> bool:
        """Validate stock value"""
        return cls.VALIDATION['min_stock'] <= stock <= cls.VALIDATION['max_stock']
        
    @classmethod
    def validate_rating(cls, rating: int) -> bool:
        """Validate rating value"""
        return cls.VALIDATION['min_rating'] <= rating <= cls.VALIDATION['max_rating']
        
    @classmethod
    def is_super_admin(cls, user_id: int) -> bool:
        """Check if user is super admin"""
        return user_id == cls.SUPER_ADMIN_ID and cls.SUPER_ADMIN_ID != 0
        
    @classmethod
    def get_bot_token(cls) -> str:
        """Get bot token with validation"""
        token = cls.BOT_TOKEN
        if not token or token == 'YOUR_BOT_TOKEN_HERE':
            raise ValueError("Bot token not configured. Please set BOT_TOKEN environment variable.")
        return token
    
    @classmethod
    def get_log_config(cls) -> Dict[str, Any]:
        """Get logging configuration"""
        return {
            'level': cls.LOG_LEVEL,
            'file': cls.LOG_FILE,
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        }
