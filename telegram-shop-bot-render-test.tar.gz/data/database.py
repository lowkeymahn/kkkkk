"""
Database management for the Telegram shop bot
"""
import json
import os
import logging
from typing import List, Optional, Dict, Any
from data.models import User, Product, Order, CartItem
from datetime import datetime

logger = logging.getLogger(__name__)

class Database:
    def __init__(self, data_dir="data"):
        self.data_dir = data_dir
        self.ensure_data_directory()
        
        # File paths
        self.users_file = os.path.join(data_dir, "users.json")
        self.products_file = os.path.join(data_dir, "products.json")
        self.orders_file = os.path.join(data_dir, "orders.json")
        self.carts_file = os.path.join(data_dir, "carts.json")
        self.wishlists_file = os.path.join(data_dir, "wishlists.json")
        self.ratings_file = os.path.join(data_dir, "ratings.json")
        self.admins_file = os.path.join(data_dir, "admins.json")

        self.categories_file = os.path.join(data_dir, "categories.json")
        self.operators_file = os.path.join(data_dir, "operators.json")
        self.payment_methods_file = os.path.join(data_dir, "payment_methods.json")
        self.bot_settings_file = os.path.join(data_dir, "bot_settings.json")
        
        # Initialize files if they don't exist
        self.initialize_files()
        
    def ensure_data_directory(self):
        """Ensure data directory exists"""
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)
            logger.info(f"Created data directory: {self.data_dir}")
            
    def initialize_files(self):
        """Initialize JSON files if they don't exist"""
        default_data = {
            self.users_file: {},
            self.products_file: {},
            self.orders_file: {},
            self.carts_file: {},
            self.wishlists_file: {},
            self.ratings_file: {},
            self.admins_file: {"admins": []},

            self.categories_file: {},
            self.operators_file: {},
            self.payment_methods_file: {},
            self.bot_settings_file: {}
        }
        
        for file_path, default_content in default_data.items():
            if not os.path.exists(file_path):
                with open(file_path, 'w') as f:
                    json.dump(default_content, f, indent=2)
                logger.info(f"Initialized file: {file_path}")
                
        # Add some sample products if products file is empty
        self.add_sample_products()
        
    def add_sample_products(self):
        """Add sample products for testing"""
        products = self.load_json(self.products_file)
        
        if not products:
            sample_products = [
                {
                    "id": 1,
                    "name": "Testosterone Acetate Powder",
                    "price": 45.99,
                    "description": "High purity testosterone acetate powder for research purposes. Fast-acting compound with short half-life.",
                    "stock": 50,
                    "rating": 4.5,
                    "category": "Acetate Powder",
                    "image_url": "https://via.placeholder.com/300x200?text=Testosterone+Acetate"
                },
                {
                    "id": 2,
                    "name": "Trenbolone Acetate Powder",
                    "price": 89.99,
                    "description": "Premium trenbolone acetate powder. Highly potent compound for advanced research applications.",
                    "stock": 30,
                    "rating": 4.8,
                    "category": "Acetate Powder",
                    "image_url": "https://via.placeholder.com/300x200?text=Trenbolone+Acetate"
                },
                {
                    "id": 3,
                    "name": "Masteron Propionate Powder",
                    "price": 67.99,
                    "description": "High-quality masteron propionate powder. Known for its hardening properties in research.",
                    "stock": 40,
                    "rating": 4.6,
                    "category": "Propionate Powder",
                    "image_url": "https://via.placeholder.com/300x200?text=Masteron+Propionate"
                },
                {
                    "id": 4,
                    "name": "Testosterone Propionate Powder",
                    "price": 42.99,
                    "description": "Pure testosterone propionate powder. Short-acting ester for precise research timing.",
                    "stock": 60,
                    "rating": 4.4,
                    "category": "Propionate Powder",
                    "image_url": "https://via.placeholder.com/300x200?text=Testosterone+Propionate"
                },
                {
                    "id": 5,
                    "name": "Testosterone Enanthate Powder",
                    "price": 38.99,
                    "description": "Long-acting testosterone enanthate powder. Stable compound for extended research periods.",
                    "stock": 80,
                    "rating": 4.7,
                    "category": "Enanthate Powder",
                    "image_url": "https://via.placeholder.com/300x200?text=Testosterone+Enanthate"
                },
                {
                    "id": 6,
                    "name": "Nandrolone Decanoate Powder",
                    "price": 55.99,
                    "description": "Premium nandrolone decanoate powder. Long-acting compound for sustained research.",
                    "stock": 45,
                    "rating": 4.5,
                    "category": "Decanoate Powder",
                    "image_url": "https://via.placeholder.com/300x200?text=Nandrolone+Decanoate"
                }
            ]
            
            for product_data in sample_products:
                product = Product(**product_data)
                products[str(product.id)] = product.to_dict()
                
            self.save_json(self.products_file, products)
            logger.info("Added sample products to database")
            
    def load_json(self, file_path: str) -> Dict[str, Any]:
        """Load JSON data from file"""
        try:
            with open(file_path, 'r') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            logger.error(f"Error loading {file_path}: {e}")
            return {}
            
    def save_json(self, file_path: str, data: Dict[str, Any]):
        """Save JSON data to file"""
        try:
            with open(file_path, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving {file_path}: {e}")
            
    # User management
    def save_user(self, user: User) -> bool:
        """Save user to database"""
        try:
            users = self.load_json(self.users_file)
            users[str(user.id)] = user.to_dict()
            self.save_json(self.users_file, users)
            return True
        except Exception as e:
            logger.error(f"Error saving user: {e}")
            return False
            
    def get_user(self, user_id: int) -> Optional[User]:
        """Get user from database"""
        try:
            users = self.load_json(self.users_file)
            user_data = users.get(str(user_id))
            if user_data:
                return User.from_dict(user_data)
            return None
        except Exception as e:
            logger.error(f"Error getting user: {e}")
            return None
            
    def get_all_users(self) -> List[User]:
        """Get all users from database"""
        try:
            users = self.load_json(self.users_file)
            return [User.from_dict(user_data) for user_data in users.values()]
        except Exception as e:
            logger.error(f"Error getting all users: {e}")
            return []
            
    # Product management
    def save_product(self, product: Product) -> bool:
        """Save product to database"""
        try:
            products = self.load_json(self.products_file)
            products[str(product.id)] = product.to_dict()
            self.save_json(self.products_file, products)
            return True
        except Exception as e:
            logger.error(f"Error saving product: {e}")
            return False
            
    def get_product(self, product_id: int) -> Optional[Product]:
        """Get product from database"""
        try:
            products = self.load_json(self.products_file)
            product_data = products.get(str(product_id))
            if product_data:
                return Product.from_dict(product_data)
            return None
        except Exception as e:
            logger.error(f"Error getting product: {e}")
            return None
            
    def get_products(self) -> List[Product]:
        """Get all products from database"""
        try:
            products = self.load_json(self.products_file)
            return [Product.from_dict(product_data) for product_data in products.values()]
        except Exception as e:
            logger.error(f"Error getting all products: {e}")
            return []
            
    def get_categories(self) -> List[str]:
        """Get all unique categories from products"""
        try:
            products = self.get_products()
            categories = list(set(product.category for product in products))
            return sorted(categories)
        except Exception as e:
            logger.error(f"Error getting categories: {e}")
            return []
            
    def get_products_by_category(self, category: str) -> List[Product]:
        """Get products filtered by category"""
        try:
            products = self.get_products()
            return [product for product in products if product.category == category]
        except Exception as e:
            logger.error(f"Error getting products by category: {e}")
            return []
            
    def get_next_product_id(self) -> int:
        """Get next available product ID"""
        products = self.load_json(self.products_file)
        if not products:
            return 1
        return max(int(pid) for pid in products.keys()) + 1
        
    # Order management
    def save_order(self, order: Order) -> bool:
        """Save order to database"""
        try:
            orders = self.load_json(self.orders_file)
            orders[str(order.id)] = order.to_dict()
            self.save_json(self.orders_file, orders)
            return True
        except Exception as e:
            logger.error(f"Error saving order: {e}")
            return False
            
    def get_order(self, order_id: int) -> Optional[Order]:
        """Get order from database"""
        try:
            orders = self.load_json(self.orders_file)
            order_data = orders.get(str(order_id))
            if order_data:
                return Order.from_dict(order_data)
            return None
        except Exception as e:
            logger.error(f"Error getting order: {e}")
            return None
            
    def get_user_orders(self, user_id: int) -> List[Order]:
        """Get all orders for a user"""
        try:
            orders = self.load_json(self.orders_file)
            user_orders = []
            for order_data in orders.values():
                if order_data.get('user_id') == user_id:
                    user_orders.append(Order.from_dict(order_data))
            return sorted(user_orders, key=lambda x: x.created_at, reverse=True)
        except Exception as e:
            logger.error(f"Error getting user orders: {e}")
            return []
            
    def get_all_orders(self) -> List[Order]:
        """Get all orders from database"""
        try:
            orders = self.load_json(self.orders_file)
            return [Order.from_dict(order_data) for order_data in orders.values()]
        except Exception as e:
            logger.error(f"Error getting all orders: {e}")
            return []
            
    def get_next_order_id(self) -> int:
        """Get next available order ID"""
        orders = self.load_json(self.orders_file)
        if not orders:
            return 1
        return max(int(oid) for oid in orders.keys()) + 1
        
    def create_order(self, user_id: int) -> Optional[Order]:
        """Create order from user's cart"""
        try:
            cart = self.get_user_cart(user_id)
            if not cart:
                return None
                
            # Calculate total
            total = 0
            for item in cart:
                product = self.get_product(item['product_id'])
                if product:
                    total += product.price * item['quantity']
                    
            # Create order
            order = Order(
                id=self.get_next_order_id(),
                user_id=user_id,
                items=cart,
                total=total,
                status="pending",
                created_at=datetime.now().isoformat()
            )
            
            if self.save_order(order):
                self.clear_user_cart(user_id)
                return order
                
            return None
        except Exception as e:
            logger.error(f"Error creating order: {e}")
            return None
            
    # Cart management
    def get_user_cart(self, user_id: int) -> List[Dict]:
        """Get user's cart"""
        try:
            carts = self.load_json(self.carts_file)
            return carts.get(str(user_id), [])
        except Exception as e:
            logger.error(f"Error getting user cart: {e}")
            return []
            
    def add_to_cart(self, user_id: int, product_id: int, quantity: int = 1) -> bool:
        """Add item to user's cart"""
        try:
            carts = self.load_json(self.carts_file)
            user_cart = carts.get(str(user_id), [])
            
            # Check if item already in cart
            for item in user_cart:
                if item['product_id'] == product_id:
                    item['quantity'] += quantity
                    break
            else:
                user_cart.append({
                    'product_id': product_id,
                    'quantity': quantity,
                    'added_at': datetime.now().isoformat()
                })
                
            carts[str(user_id)] = user_cart
            self.save_json(self.carts_file, carts)
            return True
        except Exception as e:
            logger.error(f"Error adding to cart: {e}")
            return False
            
    def remove_from_cart(self, user_id: int, product_id: int) -> bool:
        """Remove item from user's cart"""
        try:
            carts = self.load_json(self.carts_file)
            user_cart = carts.get(str(user_id), [])
            
            user_cart = [item for item in user_cart if item['product_id'] != product_id]
            carts[str(user_id)] = user_cart
            self.save_json(self.carts_file, carts)
            return True
        except Exception as e:
            logger.error(f"Error removing from cart: {e}")
            return False
            
    def clear_user_cart(self, user_id: int) -> bool:
        """Clear user's cart"""
        try:
            carts = self.load_json(self.carts_file)
            carts[str(user_id)] = []
            self.save_json(self.carts_file, carts)
            return True
        except Exception as e:
            logger.error(f"Error clearing cart: {e}")
            return False
            
    # Wishlist management
    def get_user_wishlist(self, user_id: int) -> List[Dict]:
        """Get user's wishlist"""
        try:
            wishlists = self.load_json(self.wishlists_file)
            return wishlists.get(str(user_id), [])
        except Exception as e:
            logger.error(f"Error getting user wishlist: {e}")
            return []
            
    def add_to_wishlist(self, user_id: int, product_id: int) -> bool:
        """Add item to user's wishlist"""
        try:
            wishlists = self.load_json(self.wishlists_file)
            user_wishlist = wishlists.get(str(user_id), [])
            
            # Check if item already in wishlist
            for item in user_wishlist:
                if item['product_id'] == product_id:
                    return False  # Already in wishlist
                    
            user_wishlist.append({
                'product_id': product_id,
                'added_at': datetime.now().isoformat()
            })
            
            wishlists[str(user_id)] = user_wishlist
            self.save_json(self.wishlists_file, wishlists)
            return True
        except Exception as e:
            logger.error(f"Error adding to wishlist: {e}")
            return False
            
    def remove_from_wishlist(self, user_id: int, product_id: int) -> bool:
        """Remove item from user's wishlist"""
        try:
            wishlists = self.load_json(self.wishlists_file)
            user_wishlist = wishlists.get(str(user_id), [])
            
            user_wishlist = [item for item in user_wishlist if item['product_id'] != product_id]
            wishlists[str(user_id)] = user_wishlist
            self.save_json(self.wishlists_file, wishlists)
            return True
        except Exception as e:
            logger.error(f"Error removing from wishlist: {e}")
            return False
            
    # Rating management
    def add_product_rating(self, product_id: int, user_id: int, rating: int) -> bool:
        """Add rating for a product"""
        try:
            ratings = self.load_json(self.ratings_file)
            
            # Create rating entry
            rating_key = f"{product_id}_{user_id}"
            ratings[rating_key] = {
                'product_id': product_id,
                'user_id': user_id,
                'rating': rating,
                'created_at': datetime.now().isoformat()
            }
            
            self.save_json(self.ratings_file, ratings)
            return True
        except Exception as e:
            logger.error(f"Error adding rating: {e}")
            return False
            
    def get_product_ratings(self, product_id: int) -> List[int]:
        """Get all ratings for a product"""
        try:
            ratings = self.load_json(self.ratings_file)
            product_ratings = []
            
            for rating_data in ratings.values():
                if rating_data.get('product_id') == product_id:
                    product_ratings.append(rating_data['rating'])
                    
            return product_ratings
        except Exception as e:
            logger.error(f"Error getting product ratings: {e}")
            return []
    
    def get_weekly_ratings_statistics(self) -> Dict[str, Any]:
        """Get ratings statistics for the past week"""
        try:
            from datetime import datetime, timedelta
            ratings = self.load_json(self.ratings_file)
            products = self.load_json(self.products_file)
            
            # Calculate date one week ago
            one_week_ago = datetime.now() - timedelta(days=7)
            
            # Filter ratings from the past week
            weekly_ratings = {}
            for rating_data in ratings.values():
                rating_date = datetime.fromisoformat(rating_data['created_at'])
                if rating_date >= one_week_ago:
                    product_id = rating_data['product_id']
                    if product_id not in weekly_ratings:
                        weekly_ratings[product_id] = {
                            'ratings': [],
                            'raters': set()
                        }
                    weekly_ratings[product_id]['ratings'].append(rating_data['rating'])
                    weekly_ratings[product_id]['raters'].add(rating_data['user_id'])
            
            # Process statistics
            result = []
            for product_id, data in weekly_ratings.items():
                product = products.get(str(product_id))
                if product:
                    ratings_list = data['ratings']
                    raters_count = len(data['raters'])
                    
                    # Calculate statistics
                    avg_rating = sum(ratings_list) / len(ratings_list)
                    stars_count = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
                    for rating in ratings_list:
                        stars_count[rating] += 1
                    
                    result.append({
                        'product_id': product_id,
                        'product_name': product['name'],
                        'product_price': product['price'],
                        'product_category': product['category'],
                        'total_ratings': len(ratings_list),
                        'unique_raters': raters_count,
                        'average_rating': avg_rating,
                        'stars_distribution': stars_count
                    })
            
            # Sort by number of ratings (most active first)
            result.sort(key=lambda x: x['total_ratings'], reverse=True)
            return result
            
        except Exception as e:
            logger.error(f"Error getting weekly ratings statistics: {e}")
            return []
            
    # Admin management
    def is_admin(self, user_id: int) -> bool:
        """Check if user is an admin"""
        try:
            admins = self.load_json(self.admins_file)
            return user_id in admins.get('admins', [])
        except Exception as e:
            logger.error(f"Error checking admin status: {e}")
            return False
            
    def add_admin(self, user_id: int) -> bool:
        """Add user as admin"""
        try:
            admins = self.load_json(self.admins_file)
            admin_list = admins.get('admins', [])
            
            if user_id not in admin_list:
                admin_list.append(user_id)
                admins['admins'] = admin_list
                self.save_json(self.admins_file, admins)
                
            return True
        except Exception as e:
            logger.error(f"Error adding admin: {e}")
            return False
            
    def remove_admin(self, user_id: int) -> bool:
        """Remove user from admin"""
        try:
            admins = self.load_json(self.admins_file)
            admin_list = admins.get('admins', [])
            
            if user_id in admin_list:
                admin_list.remove(user_id)
                admins['admins'] = admin_list
                self.save_json(self.admins_file, admins)
                
            return True
        except Exception as e:
            logger.error(f"Error removing admin: {e}")
            return False
            
    # Statistics
    def get_statistics(self) -> Dict[str, Any]:
        """Get database statistics"""
        try:
            users = self.load_json(self.users_file)
            products = self.load_json(self.products_file)
            orders = self.load_json(self.orders_file)
            
            total_revenue = 0
            for order_data in orders.values():
                if order_data.get('status') == 'completed':
                    total_revenue += order_data.get('total', 0)
                    
            return {
                'total_users': len(users),
                'total_products': len(products),
                'total_orders': len(orders),
                'total_revenue': total_revenue,
                'completed_orders': len([o for o in orders.values() if o.get('status') == 'completed']),
                'pending_orders': len([o for o in orders.values() if o.get('status') == 'pending'])
            }
        except Exception as e:
            logger.error(f"Error getting statistics: {e}")
            return {}
    

    
    # Categories Management
    def get_categories(self) -> Dict[str, Any]:
        """Get all categories"""
        try:
            return self.load_json(self.categories_file)
        except Exception as e:
            logger.error(f"Error getting categories: {e}")
            return {}
    
    def save_categories(self, categories: Dict[str, Any]) -> bool:
        """Save categories"""
        try:
            self.save_json(self.categories_file, categories)
            return True
        except Exception as e:
            logger.error(f"Error saving categories: {e}")
            return False
    
    # Operators Management
    def get_operators(self) -> Dict[str, Any]:
        """Get all operators"""
        try:
            return self.load_json(self.operators_file)
        except Exception as e:
            logger.error(f"Error getting operators: {e}")
            return {}
    
    def save_operators(self, operators: Dict[str, Any]) -> bool:
        """Save operators"""
        try:
            self.save_json(self.operators_file, operators)
            return True
        except Exception as e:
            logger.error(f"Error saving operators: {e}")
            return False
    
    # Payment Methods Management
    def get_payment_methods(self) -> Dict[str, Any]:
        """Get all payment methods"""
        try:
            return self.load_json(self.payment_methods_file)
        except Exception as e:
            logger.error(f"Error getting payment methods: {e}")
            return {}
    
    def save_payment_methods(self, methods: Dict[str, Any]) -> bool:
        """Save payment methods"""
        try:
            self.save_json(self.payment_methods_file, methods)
            return True
        except Exception as e:
            logger.error(f"Error saving payment methods: {e}")
            return False
    
    # Bot Settings Management
    def get_bot_settings(self) -> Dict[str, Any]:
        """Get bot settings"""
        try:
            return self.load_json(self.bot_settings_file)
        except Exception as e:
            logger.error(f"Error getting bot settings: {e}")
            return {}
    
    def save_bot_settings(self, settings: Dict[str, Any]) -> bool:
        """Save bot settings"""
        try:
            self.save_json(self.bot_settings_file, settings)
            return True
        except Exception as e:
            logger.error(f"Error saving bot settings: {e}")
            return False
    
    def get_bot_setting(self, setting_key: str, default_value: str = None) -> str:
        """Get a specific bot setting"""
        try:
            settings = self.get_bot_settings()
            return settings.get(setting_key, default_value)
        except Exception as e:
            logger.error(f"Error getting bot setting: {e}")
            return default_value
