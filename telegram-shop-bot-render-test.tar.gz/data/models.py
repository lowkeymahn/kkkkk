"""
Data models for the Telegram shop bot
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from datetime import datetime

@dataclass
class User:
    """User model"""
    id: int
    username: str
    first_name: str = ""
    last_name: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    is_active: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert user to dictionary"""
        return {
            'id': self.id,
            'username': self.username,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'created_at': self.created_at,
            'is_active': self.is_active
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'User':
        """Create user from dictionary"""
        return cls(
            id=data['id'],
            username=data['username'],
            first_name=data.get('first_name', ''),
            last_name=data.get('last_name', ''),
            created_at=data.get('created_at', datetime.now().isoformat()),
            is_active=data.get('is_active', True)
        )
        
    def get_full_name(self) -> str:
        """Get user's full name"""
        return f"{self.first_name} {self.last_name}".strip() or self.username

@dataclass
class Product:
    """Product model"""
    id: int
    name: str
    price: float
    description: str
    stock: int = 0
    rating: float = 0.0
    category: str = "General"
    image_url: str = ""
    is_active: bool = True
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert product to dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'price': self.price,
            'description': self.description,
            'stock': self.stock,
            'rating': self.rating,
            'category': self.category,
            'image_url': self.image_url,
            'is_active': self.is_active,
            'created_at': self.created_at
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Product':
        """Create product from dictionary"""
        return cls(
            id=data['id'],
            name=data['name'],
            price=data['price'],
            description=data['description'],
            stock=data.get('stock', 0),
            rating=data.get('rating', 0.0),
            category=data.get('category', 'General'),
            image_url=data.get('image_url', ''),
            is_active=data.get('is_active', True),
            created_at=data.get('created_at', datetime.now().isoformat())
        )
        
    def is_available(self) -> bool:
        """Check if product is available"""
        return self.is_active and self.stock > 0
        
    def get_price_formatted(self) -> str:
        """Get formatted price string"""
        return f"${self.price:.2f}"
        
    def get_stock_status(self) -> str:
        """Get stock status string"""
        if self.stock == 0:
            return "Out of Stock"
        elif self.stock < 10:
            return f"Low Stock ({self.stock} left)"
        else:
            return "In Stock"

@dataclass
class CartItem:
    """Cart item model"""
    product_id: int
    quantity: int = 1
    added_at: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert cart item to dictionary"""
        return {
            'product_id': self.product_id,
            'quantity': self.quantity,
            'added_at': self.added_at
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'CartItem':
        """Create cart item from dictionary"""
        return cls(
            product_id=data['product_id'],
            quantity=data.get('quantity', 1),
            added_at=data.get('added_at', datetime.now().isoformat())
        )

@dataclass
class Order:
    """Order model"""
    id: int
    user_id: int
    items: List[Dict[str, Any]]
    total: float
    status: str = "pending"  # pending, confirmed, shipped, completed, cancelled
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    shipping_address: str = ""
    payment_method: str = ""
    tracking_number: str = ""
    notes: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert order to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'items': self.items,
            'total': self.total,
            'status': self.status,
            'created_at': self.created_at,
            'updated_at': self.updated_at,
            'shipping_address': self.shipping_address,
            'payment_method': self.payment_method,
            'tracking_number': self.tracking_number,
            'notes': self.notes
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Order':
        """Create order from dictionary"""
        return cls(
            id=data['id'],
            user_id=data['user_id'],
            items=data['items'],
            total=data['total'],
            status=data.get('status', 'pending'),
            created_at=data.get('created_at', datetime.now().isoformat()),
            updated_at=data.get('updated_at', datetime.now().isoformat()),
            shipping_address=data.get('shipping_address', ''),
            payment_method=data.get('payment_method', ''),
            tracking_number=data.get('tracking_number', ''),
            notes=data.get('notes', '')
        )
        
    def get_status_emoji(self) -> str:
        """Get emoji for order status"""
        status_emojis = {
            'pending': '⏳',
            'confirmed': '✅',
            'shipped': '🚚',
            'completed': '✅',
            'cancelled': '❌'
        }
        return status_emojis.get(self.status, '❓')
        
    def get_total_formatted(self) -> str:
        """Get formatted total string"""
        return f"${self.total:.2f}"
        
    def get_items_count(self) -> int:
        """Get total number of items in order"""
        return sum(item.get('quantity', 1) for item in self.items)
        
    def update_status(self, new_status: str):
        """Update order status"""
        self.status = new_status
        self.updated_at = datetime.now().isoformat()

@dataclass
class Rating:
    """Rating model"""
    id: int
    product_id: int
    user_id: int
    rating: int  # 1-5 stars
    comment: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert rating to dictionary"""
        return {
            'id': self.id,
            'product_id': self.product_id,
            'user_id': self.user_id,
            'rating': self.rating,
            'comment': self.comment,
            'created_at': self.created_at
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Rating':
        """Create rating from dictionary"""
        return cls(
            id=data['id'],
            product_id=data['product_id'],
            user_id=data['user_id'],
            rating=data['rating'],
            comment=data.get('comment', ''),
            created_at=data.get('created_at', datetime.now().isoformat())
        )
        
    def get_stars_display(self) -> str:
        """Get star display string"""
        return '⭐' * self.rating + '☆' * (5 - self.rating)
        
    def validate_rating(self) -> bool:
        """Validate rating value"""
        return 1 <= self.rating <= 5

@dataclass
class WishlistItem:
    """Wishlist item model"""
    product_id: int
    added_at: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert wishlist item to dictionary"""
        return {
            'product_id': self.product_id,
            'added_at': self.added_at
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'WishlistItem':
        """Create wishlist item from dictionary"""
        return cls(
            product_id=data['product_id'],
            added_at=data.get('added_at', datetime.now().isoformat())
        )

@dataclass
class AdminAction:
    """Admin action model for logging"""
    id: int
    admin_id: int
    action: str
    target_type: str  # user, product, order
    target_id: int
    details: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert admin action to dictionary"""
        return {
            'id': self.id,
            'admin_id': self.admin_id,
            'action': self.action,
            'target_type': self.target_type,
            'target_id': self.target_id,
            'details': self.details,
            'timestamp': self.timestamp
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AdminAction':
        """Create admin action from dictionary"""
        return cls(
            id=data['id'],
            admin_id=data['admin_id'],
            action=data['action'],
            target_type=data['target_type'],
            target_id=data['target_id'],
            details=data.get('details', ''),
            timestamp=data.get('timestamp', datetime.now().isoformat())
        )
