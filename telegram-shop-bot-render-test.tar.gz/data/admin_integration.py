"""
Integration layer between admin dashboard and bot
"""
import os
import sys
import json
from datetime import datetime
from typing import Dict, List, Any, Optional

# Add the project root to Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data.database import Database
from data.models import Product, User, Order
from config import Config

class AdminBotIntegration:
    """Integration between admin dashboard and bot functionality"""
    
    def __init__(self):
        self.db = Database()
        self.config = Config()
    
    def sync_products_from_admin(self, admin_products: List[Dict]) -> bool:
        """Sync products from admin dashboard to bot database"""
        try:
            # Load existing products from file
            products_file = os.path.join(self.config.DATA_DIRECTORY, 'products.json')
            
            # Clear existing products and add new ones
            new_products = {}
            
            for admin_product in admin_products:
                product_id = str(admin_product.get('id', len(new_products) + 1))
                
                # Create product compatible with bot
                product_dict = {
                    'id': product_id,
                    'name': admin_product['name'],
                    'price': float(admin_product['price']),
                    'description': admin_product.get('description', ''),
                    'stock': int(admin_product.get('stock', 0)),
                    'category': admin_product.get('category', 'General'),
                    'image_url': admin_product.get('image_url', ''),
                    'is_active': admin_product.get('is_active', True),
                    'rating': 0.0,
                    'rating_count': 0
                }
                
                new_products[product_id] = product_dict
            
            # Save to bot database file
            with open(products_file, 'w') as f:
                json.dump(new_products, f, indent=2)
            return True
            
        except Exception as e:
            print(f"Error syncing products: {e}")
            return False
    
    def sync_categories_from_admin(self, admin_categories: List[Dict]) -> bool:
        """Sync categories from admin dashboard to bot"""
        try:
            # Create categories file for bot
            categories_file = os.path.join(self.config.DATA_DIRECTORY, 'categories.json')
            
            bot_categories = {}
            for admin_category in admin_categories:
                if admin_category.get('is_active', True):
                    bot_categories[admin_category['name']] = {
                        'id': admin_category['id'],
                        'name': admin_category['name'],
                        'description': admin_category.get('description', ''),
                        'is_active': admin_category.get('is_active', True)
                    }
            
            with open(categories_file, 'w') as f:
                json.dump(bot_categories, f, indent=2)
            
            return True
            
        except Exception as e:
            print(f"Error syncing categories: {e}")
            return False
    
    def sync_payment_methods_from_admin(self, admin_payment_methods: List[Dict]) -> bool:
        """Sync payment methods from admin dashboard to bot"""
        try:
            # Create payment methods file for bot
            payment_file = os.path.join(self.config.DATA_DIRECTORY, 'payment_methods.json')
            
            bot_payment_methods = {}
            for admin_method in admin_payment_methods:
                if admin_method.get('is_active', True):
                    bot_payment_methods[admin_method['name']] = {
                        'id': admin_method['id'],
                        'name': admin_method['name'],
                        'type': admin_method.get('type', 'digital'),
                        'wallet_address': admin_method.get('wallet_address', ''),
                        'qr_code_url': admin_method.get('qr_code_url', ''),
                        'instructions': admin_method.get('instructions', ''),
                        'is_active': admin_method.get('is_active', True)
                    }
            
            with open(payment_file, 'w') as f:
                json.dump(bot_payment_methods, f, indent=2)
            
            return True
            
        except Exception as e:
            print(f"Error syncing payment methods: {e}")
            return False
    

    
    def sync_operators_from_admin(self, admin_operators: List[Dict]) -> bool:
        """Sync operators from admin dashboard to bot"""
        try:
            # Create operators file for bot
            operators_file = os.path.join(self.config.DATA_DIRECTORY, 'operators.json')
            
            bot_operators = {}
            for admin_operator in admin_operators:
                if admin_operator.get('is_active', True):
                    bot_operators[str(admin_operator['id'])] = {
                        'id': admin_operator['id'],
                        'name': admin_operator['name'],
                        'telegram_username': admin_operator.get('telegram_username', ''),
                        'telegram_id': admin_operator.get('telegram_id'),
                        'email': admin_operator.get('email', ''),
                        'phone': admin_operator.get('phone', ''),
                        'working_hours': admin_operator.get('working_hours', ''),
                        'is_active': admin_operator.get('is_active', True)
                    }
            
            with open(operators_file, 'w') as f:
                json.dump(bot_operators, f, indent=2)
            
            return True
            
        except Exception as e:
            print(f"Error syncing operators: {e}")
            return False
    
    def get_bot_stats(self) -> Dict[str, Any]:
        """Get bot statistics for admin dashboard"""
        try:
            # Load from files directly
            users_file = os.path.join(self.config.DATA_DIRECTORY, 'users.json')
            products_file = os.path.join(self.config.DATA_DIRECTORY, 'products.json')
            orders_file = os.path.join(self.config.DATA_DIRECTORY, 'orders.json')
            
            users = {}
            products = {}
            orders = {}
            
            if os.path.exists(users_file):
                with open(users_file, 'r') as f:
                    users = json.load(f)
            
            if os.path.exists(products_file):
                with open(products_file, 'r') as f:
                    products = json.load(f)
                    
            if os.path.exists(orders_file):
                with open(orders_file, 'r') as f:
                    orders = json.load(f)
            
            # Calculate statistics
            stats = {
                'total_users': len(users),
                'total_products': len(products),
                'total_orders': len(orders),
                'active_products': len([p for p in products.values() if p.get('is_active', True)]),
                'recent_orders': len([o for o in orders.values() if self._is_recent_order(o)]),
                'total_revenue': sum(float(o.get('total', 0)) for o in orders.values()),
                'low_stock_products': len([p for p in products.values() if int(p.get('stock', 0)) < 10])
            }
            
            return stats
            
        except Exception as e:
            print(f"Error getting bot stats: {e}")
            return {}
    
    def _is_recent_order(self, order: Dict) -> bool:
        """Check if order is from last 7 days"""
        try:
            if 'created_at' not in order:
                return False
            
            order_date = datetime.fromisoformat(order['created_at'].replace('Z', '+00:00'))
            days_ago = (datetime.now() - order_date).days
            return days_ago <= 7
            
        except Exception:
            return False
    
    def sync_bot_settings_from_admin(self, admin_settings: Dict) -> bool:
        """Sync bot settings from admin dashboard to bot"""
        try:
            # Create bot settings file
            settings_file = os.path.join(self.config.DATA_DIRECTORY, 'bot_settings.json')
            
            # Save settings to bot database
            with open(settings_file, 'w') as f:
                json.dump(admin_settings, f, indent=2)
            
            return True
            
        except Exception as e:
            print(f"Error syncing bot settings: {e}")
            return False
    
    def full_sync_from_admin(self, admin_data: Dict) -> Dict[str, bool]:
        """Perform full sync from admin dashboard to bot"""
        results = {}
        
        if 'products' in admin_data:
            results['products'] = self.sync_products_from_admin(admin_data['products'])
        
        if 'categories' in admin_data:
            results['categories'] = self.sync_categories_from_admin(admin_data['categories'])
        
        if 'payment_methods' in admin_data:
            results['payment_methods'] = self.sync_payment_methods_from_admin(admin_data['payment_methods'])
        
        if 'bot_settings' in admin_data:
            results['bot_settings'] = self.sync_bot_settings_from_admin(admin_data['bot_settings'])
        
        if 'operators' in admin_data:
            results['operators'] = self.sync_operators_from_admin(admin_data['operators'])
        
        return results

# Global integration instance
integration = AdminBotIntegration()