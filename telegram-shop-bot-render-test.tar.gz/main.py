#!/usr/bin/env python3
"""
Telegram Shop Bot with Vanishing Messages
Main entry point for the bot application
"""
import asyncio
import logging
import os
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackQueryHandler
from bot.handlers import BotHandlers
from bot.commands import BotCommands
from data.database import Database
from config import Config

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

async def main():
    """Main function to initialize and run the bot"""
    # Validate bot token
    try:
        bot_token = Config.get_bot_token()
    except ValueError as e:
        logger.error(f"Configuration error: {e}")
        return
    
    # Initialize database
    db = Database()
    
    # Initialize bot commands and handlers
    bot_commands = BotCommands(db)
    bot_handlers = BotHandlers(db, bot_commands)
    
    # Create application
    application = Application.builder().token(bot_token).build()
    
    # Add command handlers
    application.add_handler(CommandHandler("start", bot_handlers.start))
    application.add_handler(CommandHandler("help", bot_handlers.help_command))
    application.add_handler(CommandHandler("listings", bot_handlers.listings))
    application.add_handler(CommandHandler("rating", bot_handlers.rating))
    application.add_handler(CommandHandler("wishlist", bot_handlers.wishlist))
    application.add_handler(CommandHandler("orders", bot_handlers.orders))
    application.add_handler(CommandHandler("cart", bot_handlers.cart))
    application.add_handler(CommandHandler("operator", bot_handlers.operator))
    application.add_handler(CommandHandler("vanish", bot_handlers.vanish_settings))
    

    
    # Add callback query handler for inline buttons
    application.add_handler(CallbackQueryHandler(bot_handlers.button_callback))
    
    # Add message handler for unknown commands
    application.add_handler(MessageHandler(filters.COMMAND, bot_handlers.unknown_command))
    
    # Add text message handler
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, bot_handlers.handle_text))
    
    # Start the bot
    logger.info("Starting Telegram Shop Bot...")
    await application.initialize()
    await application.start()
    await application.updater.start_polling()
    
    # Keep the bot running
    try:
        await asyncio.Event().wait()
    except KeyboardInterrupt:
        logger.info("Shutting down bot...")
        await application.updater.stop()
        await application.stop()
        await application.shutdown()

if __name__ == "__main__":
    asyncio.run(main())
