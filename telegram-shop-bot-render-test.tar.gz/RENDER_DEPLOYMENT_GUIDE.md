# Render Deployment Guide for Telegram Shop Bot

## Overview
This guide will help you deploy the Telegram Shop Bot to Render.com, a reliable platform with better Docker support than Railway.

## Features
- **Free PostgreSQL database** with 100MB storage
- **Automatic Docker deployment** from GitHub
- **Environment variable management** 
- **Health checks and monitoring**
- **SSL certificates** included
- **Simple deployment process**

## Prerequisites
1. GitHub account
2. Render account (free tier available)
3. Telegram bot token

## Files Included
- `render.yaml` - Render service configuration
- `Dockerfile.render` - Render-optimized Dockerfile
- `render_requirements.txt` - Python dependencies
- `RENDER_DEPLOYMENT_GUIDE.md` - This guide

## Step-by-Step Deployment

### 1. Prepare Repository
1. Extract the Render deployment package
2. Upload all files to your GitHub repository
3. Ensure the repository is public or you have Render access

### 2. Create Render Account
1. Go to [render.com](https://render.com)
2. Sign up with your GitHub account
3. Connect your GitHub repository

### 3. Deploy Database
1. In Render Dashboard, click "New +"
2. Select "PostgreSQL"
3. Configure:
   - **Name**: `telegram-shop-bot-db`
   - **Database**: `telegram_shop_bot`
   - **User**: `postgres`
   - **Region**: Oregon (or closest to you)
   - **Plan**: Free
4. Click "Create Database"
5. Save the connection details (automatically used by web service)

### 4. Deploy Web Service
1. In Render Dashboard, click "New +"
2. Select "Web Service"
3. Connect your GitHub repository
4. Configure:
   - **Name**: `telegram-shop-bot`
   - **Region**: Oregon (same as database)
   - **Branch**: main
   - **Root Directory**: . (leave blank)
   - **Runtime**: Docker
   - **Dockerfile Path**: `Dockerfile.render`
   - **Plan**: Free

### 5. Set Environment Variables
In the web service settings, add:
```
BOT_TOKEN=your_telegram_bot_token_here
PORT=5000
PYTHONUNBUFFERED=1
```

The `DATABASE_URL` will be automatically set by Render from the database connection.

### 6. Deploy
1. Click "Create Web Service"
2. Render will automatically:
   - Build Docker image
   - Install dependencies
   - Start the application
   - Set up health checks

## Alternative: Using render.yaml
If you prefer infrastructure as code:

1. Keep the `render.yaml` file in your repository
2. In Render Dashboard, click "New +"
3. Select "Blueprint"
4. Connect your repository
5. Render will automatically detect and deploy based on `render.yaml`

## Accessing Your Application
Once deployed, you'll get:
- **Admin Dashboard**: `https://your-service-name.onrender.com`
- **Telegram Bot**: Automatically connects to Telegram servers
- **Database**: PostgreSQL instance with connection details

## Default Login
- **Username**: `admin`
- **Password**: `admin123`

Change these credentials immediately after first login.

## Health Checks
Render automatically monitors your service at:
- **Health Check Path**: `/`
- **Expected Response**: 200 OK

## Troubleshooting

### Build Failures
- Check build logs in Render Dashboard
- Verify `Dockerfile.render` is in repository root
- Ensure all dependencies are in `render_requirements.txt`

### Runtime Issues
- Check application logs in Render Dashboard
- Verify `BOT_TOKEN` is set correctly
- Ensure database connection is working

### Database Connection
- Database URL is automatically provided by Render
- Connection format: `postgresql://user:password@host:port/database`
- Check database logs for connection issues

### Bot Not Responding
- Verify `BOT_TOKEN` is correct in environment variables
- Check bot logs for error messages
- Ensure bot is started in `app.py`

## Render Benefits vs Railway
- **More reliable**: Better uptime and performance
- **Clearer documentation**: Easier to understand and debug
- **Better free tier**: More generous limits
- **Docker support**: Native Docker deployment
- **Database included**: Free PostgreSQL database
- **SSL/TLS**: Automatic HTTPS certificates

## Monitoring
- **Application logs**: Available in Render Dashboard
- **Database monitoring**: Query performance and usage
- **Health checks**: Automatic service monitoring
- **Metrics**: Response times and error rates

## Scaling
- **Free tier**: 1 instance, 512MB RAM, 10GB bandwidth
- **Paid plans**: Multiple instances, more resources
- **Auto-scaling**: Available on paid plans

## Support
- **Documentation**: [render.com/docs](https://render.com/docs)
- **Community**: Discord and forums
- **Support**: Email support for paid plans

## Next Steps
1. Monitor application logs for any issues
2. Change default admin credentials
3. Test bot functionality in Telegram
4. Add products through admin dashboard
5. Configure payment methods
6. Set up operators for customer support

Your Telegram Shop Bot is now deployed and ready to use!