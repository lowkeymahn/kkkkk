"""
Bot message handlers for processing user interactions
"""
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from bot.vanishing import VanishingMessages
from data.models import User, Product, Order, CartItem
import json

logger = logging.getLogger(__name__)

class BotHandlers:
    def __init__(self, database, commands):
        self.db = database
        self.commands = commands
        self.vanishing = VanishingMessages()
        self.user_states = {}  # Track user states for address entry
        
    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Welcome message handler"""
        user_id = update.effective_user.id
        username = update.effective_user.username or "User"
        first_name = update.effective_user.first_name or ""
        
        # Create or update user
        user = User(user_id, username, first_name)
        self.db.save_user(user)
        
        # Get welcome message from admin dashboard settings
        welcome_message = self.db.get_bot_setting('welcome_message')
        
        if welcome_message:
            # Replace {username} placeholder if present
            welcome_text = welcome_message.replace('{username}', username)
        else:
            # Default welcome message
            welcome_text = f"""🛍️ Welcome to the Vanishing Shop Bot, {username}!

This bot features self-destructing messages for enhanced privacy.
Use the buttons below to navigate:"""
        
        # Create main menu keyboard
        keyboard = [
            [
                InlineKeyboardButton("🛍️ Browse Products", callback_data="cmd_listings"),
                InlineKeyboardButton("🛒 View Cart", callback_data="cmd_cart")
            ],
            [
                InlineKeyboardButton("💝 Wishlist", callback_data="cmd_wishlist"),
                InlineKeyboardButton("📦 Orders", callback_data="cmd_orders")
            ],
            [
                InlineKeyboardButton("⭐ Rating", callback_data="cmd_rating"),
                InlineKeyboardButton("👨‍💼 Support", callback_data="cmd_operator")
            ],
            [
                InlineKeyboardButton("⚙️ Vanish Settings", callback_data="cmd_vanish"),
                InlineKeyboardButton("❓ Help", callback_data="cmd_help")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        message = await update.message.reply_text(
            welcome_text, 
            reply_markup=reply_markup
        )
        await self.vanishing.schedule_deletion(message, user_id)
        
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Help command handler"""
        user_id = update.effective_user.id
        
        help_text = """
🔧 **Available Commands:**

🛍️ **Shopping:**
/listings - Browse available products
/cart - View and manage your cart
/wishlist - Manage your wishlist
/orders - View order history

⭐ **Rating:**
/rating - Rate products and services

👨‍💼 **Support:**
/operator - Contact support team

⚙️ **Settings:**
/vanish - Configure message deletion time

💡 **Tips:**
- All messages vanish automatically
- Use inline buttons for quick actions
- Contact operator for any issues
"""
        
        message = await update.message.reply_text(help_text, parse_mode='Markdown')
        await self.vanishing.schedule_deletion(message, user_id)
        
    async def listings(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle listings command"""
        user_id = update.effective_user.id
        
        # Get products from database
        products = self.db.get_products()
        
        if not products:
            message = await update.message.reply_text("📦 No products available at the moment.")
            await self.vanishing.schedule_deletion(message, user_id)
            return
            
        # Create inline keyboard for products
        keyboard = []
        for product in products[:10]:  # Show first 10 products
            keyboard.append([
                InlineKeyboardButton(
                    f"🛒 {product.name} - ${product.price:.2f}",
                    callback_data=f"product_{product.id}"
                )
            ])
            
        keyboard.append([InlineKeyboardButton("➕ Add Product (Admin)", callback_data="add_product")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        message = await update.message.reply_text(
            "🛍️ **Available Products:**\n\nClick on a product to view details:",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        await self.vanishing.schedule_deletion(message, user_id)
        
    async def rating(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle rating command - show weekly ratings statistics"""
        user_id = update.effective_user.id
        
        # Get weekly ratings statistics
        weekly_stats = self.db.get_weekly_ratings_statistics()
        
        if not weekly_stats:
            message = await update.message.reply_text(
                "⭐ **Weekly Ratings Report**\n\n"
                "No products have been rated in the past week.\n"
                "Be the first to rate a product after purchasing!"
            )
            await self.vanishing.schedule_deletion(message, user_id)
            return
            
        # Create ratings display
        ratings_text = "⭐ **Weekly Ratings Report**\n"
        ratings_text += f"📅 Products rated in the past 7 days:\n\n"
        
        keyboard = []
        
        for idx, product_stats in enumerate(weekly_stats[:10], 1):  # Show top 10
            name = product_stats['product_name']
            price = product_stats['product_price']
            category = product_stats['product_category']
            total_ratings = product_stats['total_ratings']
            unique_raters = product_stats['unique_raters']
            avg_rating = product_stats['average_rating']
            stars_dist = product_stats['stars_distribution']
            
            # Create star display
            star_display = ""
            for star in [5, 4, 3, 2, 1]:
                count = stars_dist[star]
                if count > 0:
                    star_display += f"{star}⭐: {count}  "
            
            ratings_text += f"**{idx}. {name}**\n"
            ratings_text += f"💰 ${price:.2f} | 📂 {category}\n"
            ratings_text += f"⭐ {avg_rating:.1f}/5.0 average\n"
            ratings_text += f"👥 {unique_raters} people rated ({total_ratings} total ratings)\n"
            ratings_text += f"📊 {star_display.strip()}\n\n"
            
            # Add button to view/rate this product
            keyboard.append([
                InlineKeyboardButton(
                    f"📝 View {name}",
                    callback_data=f"product_{product_stats['product_id']}"
                )
            ])
            
        # Add button to rate purchased products
        keyboard.append([
            InlineKeyboardButton(
                "⭐ Rate My Purchases",
                callback_data="rate_my_purchases"
            )
        ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        message = await update.message.reply_text(
            ratings_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        await self.vanishing.schedule_deletion(message, user_id)
        
    async def handle_rate_my_purchases(self, query):
        """Handle rate my purchases callback"""
        user_id = query.from_user.id
        
        # Get user's purchased products
        user_orders = self.db.get_user_orders(user_id)
        rated_products = []
        
        for order in user_orders:
            if order.status == "completed":
                rated_products.extend(order.items)
                
        if not rated_products:
            await query.edit_message_text(
                "⭐ You haven't completed any orders yet.\n\n"
                "Complete an order to leave ratings!",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🛍️ Shop Now", callback_data="cmd_listings")],
                    [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
                ])
            )
            return
            
        # Create rating keyboard
        keyboard = []
        seen_products = set()
        
        for item in rated_products:
            if item['product_id'] not in seen_products:
                product = self.db.get_product(item['product_id'])
                if product:
                    seen_products.add(item['product_id'])
                    keyboard.append([
                        InlineKeyboardButton(
                            f"⭐ Rate {product.name}",
                            callback_data=f"rate_{product.id}"
                        )
                    ])
        
        keyboard.append([
            InlineKeyboardButton("📊 View Weekly Ratings", callback_data="cmd_rating")
        ])
        keyboard.append([
            InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")
        ])
                
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            "⭐ **Rate Your Purchases:**\n\n"
            "Click on a product to rate it based on your experience:",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    async def wishlist(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle wishlist command"""
        user_id = update.effective_user.id
        
        wishlist = self.db.get_user_wishlist(user_id)
        
        if not wishlist:
            message = await update.message.reply_text(
                "💝 Your wishlist is empty.\n\nBrowse /listings to add items!"
            )
            await self.vanishing.schedule_deletion(message, user_id)
            return
            
        # Create wishlist display
        wishlist_text = "💝 **Your Wishlist:**\n\n"
        keyboard = []
        
        for item in wishlist:
            product = self.db.get_product(item['product_id'])
            if product:
                wishlist_text += f"• {product.name} - ${product.price:.2f}\n"
                keyboard.append([
                    InlineKeyboardButton(
                        f"🛒 Add to Cart",
                        callback_data=f"add_to_cart_{product.id}"
                    ),
                    InlineKeyboardButton(
                        f"❌ Remove",
                        callback_data=f"remove_wishlist_{product.id}"
                    )
                ])
                
        reply_markup = InlineKeyboardMarkup(keyboard)
        message = await update.message.reply_text(
            wishlist_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        await self.vanishing.schedule_deletion(message, user_id)
        
    async def orders(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle orders command"""
        user_id = update.effective_user.id
        
        orders = self.db.get_user_orders(user_id)
        
        if not orders:
            message = await update.message.reply_text(
                "📦 You haven't placed any orders yet.\n\nCheck out /listings to start shopping!"
            )
            await self.vanishing.schedule_deletion(message, user_id)
            return
            
        # Display orders
        orders_text = "📦 **Your Orders:**\n\n"
        keyboard = []
        
        for order in orders[-5:]:  # Show last 5 orders
            status_emoji = {"pending": "⏳", "confirmed": "✅", "shipped": "🚚", "completed": "✅"}
            orders_text += f"Order #{order.id}\n"
            orders_text += f"Status: {status_emoji.get(order.status, '❓')} {order.status.title()}\n"
            orders_text += f"Total: ${order.total:.2f}\n"
            orders_text += f"Date: {order.created_at}\n\n"
            
            keyboard.append([
                InlineKeyboardButton(
                    f"📋 View Order #{order.id}",
                    callback_data=f"view_order_{order.id}"
                )
            ])
            
        reply_markup = InlineKeyboardMarkup(keyboard)
        message = await update.message.reply_text(
            orders_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        await self.vanishing.schedule_deletion(message, user_id)
        
    async def cart(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle cart command"""
        user_id = update.effective_user.id
        
        cart = self.db.get_user_cart(user_id)
        
        if not cart:
            message = await update.message.reply_text(
                "🛒 Your cart is empty.\n\nBrowse /listings to add items!"
            )
            await self.vanishing.schedule_deletion(message, user_id)
            return
            
        # Display cart contents
        cart_text = "🛒 **Your Cart:**\n\n"
        total = 0
        keyboard = []
        
        for item in cart:
            product = self.db.get_product(item['product_id'])
            if product:
                subtotal = product.price * item['quantity']
                total += subtotal
                cart_text += f"• {product.name} x{item['quantity']} - ${subtotal:.2f}\n"
                
                keyboard.append([
                    InlineKeyboardButton(
                        f"➖ Remove {product.name}",
                        callback_data=f"remove_cart_{product.id}"
                    )
                ])
                
        cart_text += f"\n💰 **Total: ${total:.2f}**"
        
        keyboard.append([
            InlineKeyboardButton("🛒 Checkout", callback_data="checkout"),
            InlineKeyboardButton("🗑️ Clear Cart", callback_data="clear_cart")
        ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        message = await update.message.reply_text(
            cart_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        await self.vanishing.schedule_deletion(message, user_id)
        
    async def operator(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle operator command"""
        user_id = update.effective_user.id
        
        # Check if user is admin
        if self.db.is_admin(user_id):
            keyboard = [
                [InlineKeyboardButton("📦 Manage Products", callback_data="admin_products")],
                [InlineKeyboardButton("📋 View All Orders", callback_data="admin_orders")],
                [InlineKeyboardButton("👥 User Management", callback_data="admin_users")],
                [InlineKeyboardButton("📊 Statistics", callback_data="admin_stats")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            message = await update.message.reply_text(
                "👨‍💼 **Admin Panel**\n\nSelect an option:",
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
        else:
            keyboard = [
                [InlineKeyboardButton("📞 Contact Support", callback_data="contact_support")],
                [InlineKeyboardButton("❓ FAQ", callback_data="faq")],
                [InlineKeyboardButton("💬 Leave Feedback", callback_data="feedback")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            message = await update.message.reply_text(
                "👨‍💼 **Customer Support**\n\nHow can we help you?",
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
            
        await self.vanishing.schedule_deletion(message, user_id)
        
    async def vanish_settings(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle vanish settings command"""
        user_id = update.effective_user.id
        
        current_time = self.vanishing.get_user_vanish_time(user_id)
        
        keyboard = [
            [InlineKeyboardButton("⚡ 30 seconds", callback_data="vanish_30")],
            [InlineKeyboardButton("🕐 1 minute", callback_data="vanish_60")],
            [InlineKeyboardButton("🕐 5 minutes", callback_data="vanish_300")],
            [InlineKeyboardButton("🕐 10 minutes", callback_data="vanish_600")],
            [InlineKeyboardButton("♾️ Never", callback_data="vanish_never")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        message = await update.message.reply_text(
            f"⏰ **Vanishing Messages Settings**\n\nCurrent setting: {current_time} seconds\n\nChoose how long messages should remain visible:",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        await self.vanishing.schedule_deletion(message, user_id)
        
    async def button_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle inline button callbacks"""
        query = update.callback_query
        await query.answer()
        
        user_id = query.from_user.id
        data = query.data
        
        # Handle different callback types
        if data.startswith("cmd_"):
            await self.handle_command_button(query, data)
        elif data.startswith("category_"):
            await self.handle_category_selection(query, data)
        elif data.startswith("product_"):
            await self.handle_product_view(query, data)
        elif data.startswith("quantity_"):
            await self.handle_quantity_selection(query, data)
        elif data.startswith("add_to_cart_qty_"):
            await self.handle_add_to_cart_with_quantity(query, data)
        elif data.startswith("add_to_wishlist_"):
            await self.handle_add_to_wishlist(query, data)
        elif data.startswith("rate_"):
            await self.handle_rating(query, data)
        elif data.startswith("rating_"):
            await self.handle_rating_submission(query, data)
        elif data == "rate_my_purchases":
            await self.handle_rate_my_purchases(query)
        elif data.startswith("add_to_cart_"):
            await self.handle_add_to_cart(query, data)
        elif data.startswith("remove_cart_"):
            await self.handle_remove_from_cart(query, data)
        elif data.startswith("remove_wishlist_"):
            await self.handle_remove_from_wishlist(query, data)
        elif data.startswith("vanish_"):
            await self.handle_vanish_setting(query, data)
        elif data == "start_checkout":
            await self.handle_start_checkout(query)
        elif data.startswith("delivery_"):
            await self.handle_delivery_method(query, data)
        elif data == "enter_address":
            await self.handle_enter_address(query)
        elif data == "confirm_address":
            await self.handle_confirm_address(query)
        elif data == "payment_bitcoin":
            await self.handle_payment_method(query, data)
        elif data.startswith("payment_info_"):
            await self.handle_payment_info(query, data)
        elif data == "contact_operator":
            await self.handle_contact_operator(query)
        elif data == "contact_support":
            await self.handle_contact_support(query)
        elif data == "confirm_payment":
            await self.handle_confirm_payment(query)
        elif data == "checkout":
            await self.handle_checkout(query)
        elif data == "clear_cart":
            await self.handle_clear_cart(query)
        elif data.startswith("admin_"):
            await self.handle_admin_action(query, data)
        elif data == "back_to_menu":
            await self.handle_back_to_menu(query)
        else:
            await self.handle_general_callback(query, data)
            
    async def handle_command_button(self, query, data):
        """Handle command button callbacks"""
        user_id = query.from_user.id
        command = data.split("_")[1]  # Extract command from "cmd_command"
        
        if command == "listings":
            await self.handle_listings_from_button(query)
        elif command == "cart":
            await self.handle_cart_from_button(query)
        elif command == "wishlist":
            await self.handle_wishlist_from_button(query)
        elif command == "orders":
            await self.handle_orders_from_button(query)
        elif command == "rating":
            await self.handle_rating_from_button(query)
        elif command == "operator":
            await self.handle_operator_from_button(query)
        elif command == "vanish":
            await self.handle_vanish_from_button(query)
        elif command == "help":
            await self.handle_help_from_button(query)
            
    async def handle_back_to_menu(self, query):
        """Handle back to main menu"""
        user_id = query.from_user.id
        username = query.from_user.username or "User"
        
        welcome_text = f"""🛍️ Welcome to the Vanishing Shop Bot, {username}!

This bot features self-destructing messages for enhanced privacy.
Use the buttons below to navigate:"""
        
        # Create main menu keyboard
        keyboard = [
            [
                InlineKeyboardButton("🛍️ Browse Products", callback_data="cmd_listings"),
                InlineKeyboardButton("🛒 View Cart", callback_data="cmd_cart")
            ],
            [
                InlineKeyboardButton("💝 Wishlist", callback_data="cmd_wishlist"),
                InlineKeyboardButton("📦 Orders", callback_data="cmd_orders")
            ],
            [
                InlineKeyboardButton("⭐ Rating", callback_data="cmd_rating"),
                InlineKeyboardButton("👨‍💼 Support", callback_data="cmd_operator")
            ],
            [
                InlineKeyboardButton("⚙️ Vanish Settings", callback_data="cmd_vanish"),
                InlineKeyboardButton("❓ Help", callback_data="cmd_help")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(welcome_text, reply_markup=reply_markup)
        
    async def handle_listings_from_button(self, query):
        """Handle listings from button - show categories first"""
        user_id = query.from_user.id
        
        # Get categories from database
        categories = self.db.get_categories()
        
        if not categories:
            keyboard = [[InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_to_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text("📦 No product categories available at the moment.", reply_markup=reply_markup)
            return
            
        # Create inline keyboard for categories
        keyboard = []
        for category in categories:
            keyboard.append([
                InlineKeyboardButton(
                    f"📂 {category}",
                    callback_data=f"category_{category}"
                )
            ])
            
        keyboard.append([InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_to_menu")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            "🛍️ **Product Categories:**\n\nChoose a category to browse products:",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    async def handle_cart_from_button(self, query):
        """Handle cart from button"""
        user_id = query.from_user.id
        
        cart = self.db.get_user_cart(user_id)
        
        if not cart:
            keyboard = [[InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_to_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                "🛒 Your cart is empty.\n\nBrowse products to add items!",
                reply_markup=reply_markup
            )
            return
            
        # Display cart contents
        cart_text = "🛒 **Your Cart:**\n\n"
        total = 0
        keyboard = []
        
        for item in cart:
            product = self.db.get_product(item['product_id'])
            if product:
                subtotal = product.price * item['quantity']
                total += subtotal
                cart_text += f"• {product.name} x{item['quantity']} - ${subtotal:.2f}\n"
                
                keyboard.append([
                    InlineKeyboardButton(
                        f"➖ Remove {product.name}",
                        callback_data=f"remove_cart_{product.id}"
                    )
                ])
                
        cart_text += f"\n💰 **Total: ${total:.2f}**"
        
        keyboard.append([
            InlineKeyboardButton("💳 Proceed to Checkout", callback_data="start_checkout"),
            InlineKeyboardButton("🗑️ Clear Cart", callback_data="clear_cart")
        ])
        keyboard.append([InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_to_menu")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            cart_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    async def handle_wishlist_from_button(self, query):
        """Handle wishlist from button"""
        user_id = query.from_user.id
        
        wishlist = self.db.get_user_wishlist(user_id)
        
        if not wishlist:
            keyboard = [[InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_to_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                "💝 Your wishlist is empty.\n\nBrowse products to add items!",
                reply_markup=reply_markup
            )
            return
            
        # Create wishlist display
        wishlist_text = "💝 **Your Wishlist:**\n\n"
        keyboard = []
        
        for item in wishlist:
            product = self.db.get_product(item['product_id'])
            if product:
                wishlist_text += f"• {product.name} - ${product.price:.2f}\n"
                keyboard.append([
                    InlineKeyboardButton(
                        f"🛒 Add to Cart",
                        callback_data=f"add_to_cart_{product.id}"
                    ),
                    InlineKeyboardButton(
                        f"❌ Remove",
                        callback_data=f"remove_wishlist_{product.id}"
                    )
                ])
                
        keyboard.append([InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_to_menu")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            wishlist_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    async def handle_orders_from_button(self, query):
        """Handle orders from button"""
        user_id = query.from_user.id
        
        orders = self.db.get_user_orders(user_id)
        
        if not orders:
            keyboard = [[InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_to_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                "📦 You haven't placed any orders yet.\n\nStart shopping to place your first order!",
                reply_markup=reply_markup
            )
            return
            
        # Display orders
        orders_text = "📦 **Your Orders:**\n\n"
        keyboard = []
        
        for order in orders[-5:]:  # Show last 5 orders
            status_emoji = {"pending": "⏳", "confirmed": "✅", "shipped": "🚚", "completed": "✅"}
            orders_text += f"Order #{order.id}\n"
            orders_text += f"Status: {status_emoji.get(order.status, '❓')} {order.status.title()}\n"
            orders_text += f"Total: ${order.total:.2f}\n"
            orders_text += f"Date: {order.created_at}\n\n"
            
            keyboard.append([
                InlineKeyboardButton(
                    f"📋 View Order #{order.id}",
                    callback_data=f"view_order_{order.id}"
                )
            ])
            
        keyboard.append([InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_to_menu")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            orders_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    async def handle_rating_from_button(self, query):
        """Handle rating from button - show weekly ratings statistics"""
        user_id = query.from_user.id
        
        # Get weekly ratings statistics
        weekly_stats = self.db.get_weekly_ratings_statistics()
        
        if not weekly_stats:
            keyboard = [
                [InlineKeyboardButton("⭐ Rate My Purchases", callback_data="rate_my_purchases")],
                [InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_to_menu")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                "⭐ **Weekly Ratings Report**\n\n"
                "No products have been rated in the past week.\n"
                "Be the first to rate a product after purchasing!",
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
            return
            
        # Create ratings display
        ratings_text = "⭐ **Weekly Ratings Report**\n"
        ratings_text += f"📅 Products rated in the past 7 days:\n\n"
        
        keyboard = []
        
        for idx, product_stats in enumerate(weekly_stats[:10], 1):  # Show top 10
            name = product_stats['product_name']
            price = product_stats['product_price']
            category = product_stats['product_category']
            total_ratings = product_stats['total_ratings']
            unique_raters = product_stats['unique_raters']
            avg_rating = product_stats['average_rating']
            stars_dist = product_stats['stars_distribution']
            
            # Create star display
            star_display = ""
            for star in [5, 4, 3, 2, 1]:
                count = stars_dist[star]
                if count > 0:
                    star_display += f"{star}⭐: {count}  "
            
            ratings_text += f"**{idx}. {name}**\n"
            ratings_text += f"💰 ${price:.2f} | 📂 {category}\n"
            ratings_text += f"⭐ {avg_rating:.1f}/5.0 average\n"
            ratings_text += f"👥 {unique_raters} people rated ({total_ratings} total ratings)\n"
            ratings_text += f"📊 {star_display.strip()}\n\n"
            
            # Add button to view/rate this product
            keyboard.append([
                InlineKeyboardButton(
                    f"📝 View {name}",
                    callback_data=f"product_{product_stats['product_id']}"
                )
            ])
            
        # Add button to rate purchased products
        keyboard.append([
            InlineKeyboardButton("⭐ Rate My Purchases", callback_data="rate_my_purchases")
        ])
        keyboard.append([InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_to_menu")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            ratings_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    async def handle_operator_from_button(self, query):
        """Handle operator from button"""
        user_id = query.from_user.id
        
        # Check if user is admin
        if self.db.is_admin(user_id):
            keyboard = [
                [InlineKeyboardButton("📦 Manage Products", callback_data="admin_products")],
                [InlineKeyboardButton("📋 View All Orders", callback_data="admin_orders")],
                [InlineKeyboardButton("👥 User Management", callback_data="admin_users")],
                [InlineKeyboardButton("📊 Statistics", callback_data="admin_stats")],
                [InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_to_menu")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                "👨‍💼 **Admin Panel**\n\nSelect an option:",
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
        else:
            keyboard = [
                [InlineKeyboardButton("📞 Contact Support", callback_data="contact_support")],
                [InlineKeyboardButton("❓ FAQ", callback_data="faq")],
                [InlineKeyboardButton("💬 Leave Feedback", callback_data="feedback")],
                [InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_to_menu")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                "👨‍💼 **Customer Support**\n\nHow can we help you?",
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
            
    async def handle_vanish_from_button(self, query):
        """Handle vanish from button"""
        user_id = query.from_user.id
        
        current_time = self.vanishing.get_user_vanish_time(user_id)
        
        keyboard = [
            [InlineKeyboardButton("⚡ 30 seconds", callback_data="vanish_30")],
            [InlineKeyboardButton("🕐 1 minute", callback_data="vanish_60")],
            [InlineKeyboardButton("🕐 5 minutes", callback_data="vanish_300")],
            [InlineKeyboardButton("🕐 10 minutes", callback_data="vanish_600")],
            [InlineKeyboardButton("♾️ Never", callback_data="vanish_never")],
            [InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_to_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            f"⏰ **Vanishing Messages Settings**\n\nCurrent setting: {current_time} seconds\n\nChoose how long messages should remain visible:",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    async def handle_help_from_button(self, query):
        """Handle help from button"""
        user_id = query.from_user.id
        
        help_text = """🔧 **Available Commands:**

🛍️ **Shopping:**
• Browse Products - View available products
• Cart - Manage your shopping cart
• Wishlist - Save items for later
• Orders - View order history

⭐ **Rating:**
• Rate products and services

👨‍💼 **Support:**
• Contact support team

⚙️ **Settings:**
• Configure message deletion time

💡 **Tips:**
• All messages vanish automatically
• Use buttons for quick navigation
• Contact support for any issues
"""
        
        keyboard = [[InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_to_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(help_text, reply_markup=reply_markup, parse_mode='Markdown')
        
    async def handle_category_selection(self, query, data):
        """Handle category selection"""
        user_id = query.from_user.id
        category = data.split("_", 1)[1]  # Extract category name from "category_CategoryName"
        
        # Get products in this category
        products = self.db.get_products_by_category(category)
        
        if not products:
            keyboard = [
                [InlineKeyboardButton("⬅️ Back to Categories", callback_data="cmd_listings")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(f"📦 No products found in {category} category.", reply_markup=reply_markup)
            return
            
        # Create inline keyboard for products in category
        keyboard = []
        for product in products:
            keyboard.append([
                InlineKeyboardButton(
                    f"🛒 {product.name} - ${product.price:.2f}",
                    callback_data=f"product_{product.id}"
                )
            ])
            
        keyboard.append([
            InlineKeyboardButton("⬅️ Back to Categories", callback_data="cmd_listings"),
            InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")
        ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            f"🛍️ **{category} Products:**\n\nClick on a product to view details:",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    async def handle_quantity_selection(self, query, data):
        """Handle quantity selection for adding to cart"""
        user_id = query.from_user.id
        product_id = int(data.split("_")[1])  # Extract product_id from "quantity_1"
        
        product = self.db.get_product(product_id)
        if not product:
            await query.edit_message_text("❌ Product not found.")
            return
            
        # Create quantity selection buttons
        keyboard = []
        quantities = [1, 2, 3, 5, 10, 20, 50]  # Common quantities
        
        # Create rows of 3 buttons each
        for i in range(0, len(quantities), 3):
            row = []
            for j in range(i, min(i + 3, len(quantities))):
                qty = quantities[j]
                row.append(InlineKeyboardButton(
                    f"{qty}g",
                    callback_data=f"add_to_cart_qty_{product_id}_{qty}"
                ))
            keyboard.append(row)
            
        keyboard.append([
            InlineKeyboardButton("⬅️ Back to Product", callback_data=f"product_{product_id}"),
            InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")
        ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            f"⚖️ **Select Quantity for {product.name}:**\n\n"
            f"💰 Price: ${product.price:.2f} per gram\n"
            f"📦 Available: {product.stock}g\n\n"
            f"Choose quantity:",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    async def handle_add_to_cart_with_quantity(self, query, data):
        """Handle adding to cart with specific quantity"""
        user_id = query.from_user.id
        parts = data.split("_")
        product_id = int(parts[4])  # Extract from "add_to_cart_qty_1_5"
        quantity = int(parts[5])
        
        product = self.db.get_product(product_id)
        if not product:
            await query.edit_message_text("❌ Product not found.")
            return
            
        if quantity > product.stock:
            await query.edit_message_text(f"❌ Only {product.stock}g available in stock.")
            return
            
        # Add to cart with specific quantity
        success = self.db.add_to_cart(user_id, product_id, quantity)
        
        if success:
            total_price = product.price * quantity
            keyboard = [
                [InlineKeyboardButton("🛒 View Cart", callback_data="cmd_cart")],
                [InlineKeyboardButton("➕ Add More", callback_data=f"quantity_{product_id}")],
                [InlineKeyboardButton("⬅️ Back to Product", callback_data=f"product_{product_id}")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                f"✅ **Added to Cart!**\n\n"
                f"📦 Product: {product.name}\n"
                f"⚖️ Quantity: {quantity}g\n"
                f"💰 Total: ${total_price:.2f}",
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
        else:
            await query.edit_message_text("❌ Failed to add product to cart.")
            
    async def handle_add_to_wishlist(self, query, data):
        """Handle adding to wishlist"""
        user_id = query.from_user.id
        product_id = int(data.split("_")[3])  # Extract from "add_to_wishlist_1"
        
        product = self.db.get_product(product_id)
        if not product:
            await query.edit_message_text("❌ Product not found.")
            return
            
        success = self.db.add_to_wishlist(user_id, product_id)
        
        if success:
            # Return to main menu as requested
            await self.handle_back_to_menu(query)
        else:
            await query.edit_message_text("❌ Product already in wishlist or failed to add.")
            
    async def handle_start_checkout(self, query):
        """Handle start checkout process"""
        user_id = query.from_user.id
        
        # Verify cart is not empty
        cart = self.db.get_user_cart(user_id)
        if not cart:
            await query.edit_message_text("❌ Your cart is empty.")
            return
            
        # Show delivery method selection
        keyboard = [
            [InlineKeyboardButton("🚚 Standard Delivery (5-7 days)", callback_data="delivery_standard")],
            [InlineKeyboardButton("⚡ Express Delivery (2-3 days)", callback_data="delivery_express")],
            [InlineKeyboardButton("🏪 Pickup Location", callback_data="delivery_pickup")],
            [InlineKeyboardButton("⬅️ Back to Cart", callback_data="cmd_cart")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            "📦 **Checkout Process - Step 1/5**\n\n"
            "🚚 **Choose Delivery Method:**\n\n"
            "• Standard Delivery: FREE (5-7 business days)\n"
            "• Express Delivery: +$15 (2-3 business days)\n"
            "• Pickup Location: FREE (Available 24/7)\n\n"
            "Select your preferred delivery method:",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    async def handle_delivery_method(self, query, data):
        """Handle delivery method selection"""
        user_id = query.from_user.id
        delivery_type = data.split("_")[1]  # Extract from "delivery_standard"
        
        # Store delivery method in user context (you might want to add this to database)
        delivery_info = {
            "standard": {"name": "Standard Delivery", "cost": 0, "time": "5-7 days"},
            "express": {"name": "Express Delivery", "cost": 15, "time": "2-3 days"},
            "pickup": {"name": "Pickup Location", "cost": 0, "time": "Available 24/7"}
        }
        
        selected = delivery_info[delivery_type]
        
        keyboard = [
            [InlineKeyboardButton("📍 Enter Address", callback_data="enter_address")],
            [InlineKeyboardButton("⬅️ Back to Delivery", callback_data="start_checkout")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            f"📦 **Checkout Process - Step 2/5**\n\n"
            f"✅ **Selected:** {selected['name']}\n"
            f"💰 **Cost:** ${selected['cost']:.2f}\n"
            f"⏱️ **Delivery Time:** {selected['time']}\n\n"
            f"📍 **Next Step:** Enter your delivery address",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    async def handle_enter_address(self, query):
        """Handle address entry"""
        user_id = query.from_user.id
        
        # Set user state to address entry
        self.user_states[user_id] = "entering_address"
        
        keyboard = [
            [InlineKeyboardButton("⬅️ Back to Delivery", callback_data="start_checkout")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            "📦 **Checkout Process - Step 3/5**\n\n"
            "📍 **Enter Your Address:**\n\n"
            "Please type your complete address in the following format:\n"
            "• Full Name\n"
            "• Street Address\n"
            "• City, State, ZIP Code\n"
            "• Phone Number\n\n"
            "💡 **Example:**\n"
            "John Smith\n"
            "123 Main Street, Apt 4B\n"
            "New York, NY 10001\n"
            "(555) 123-4567\n\n"
            "📝 **Type your address now:**",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    async def handle_confirm_address(self, query):
        """Handle address confirmation"""
        user_id = query.from_user.id
        
        # Get stored address from user state
        address = "Address not found"
        if user_id in self.user_states and isinstance(self.user_states[user_id], dict):
            address = self.user_states[user_id].get("address", "Address not found")
        
        keyboard = [
            [InlineKeyboardButton("✅ Address Confirmed", callback_data="payment_bitcoin")],
            [InlineKeyboardButton("📝 Edit Address", callback_data="enter_address")],
            [InlineKeyboardButton("⬅️ Back to Delivery", callback_data="start_checkout")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            f"📦 **Checkout Process - Step 4/5**\n\n"
            f"📍 **Address Confirmed:**\n\n"
            f"{address}\n\n"
            f"✅ Address looks correct?\n"
            f"Proceed to payment method selection:",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    async def handle_payment_method(self, query, data):
        """Handle payment method selection"""
        user_id = query.from_user.id
        
        # Get cart total
        cart = self.db.get_user_cart(user_id)
        total = 0
        for item in cart:
            product = self.db.get_product(item['product_id'])
            if product:
                total += product.price * item['quantity']
        
        # Load payment methods from admin dashboard
        payment_methods = self.db.get_payment_methods()
        
        keyboard = []
        method_list = ""
        
        if payment_methods:
            for method_key, method_info in payment_methods.items():
                if method_info.get('is_active', True):
                    # Create button for each active payment method
                    method_name = method_info['name']
                    method_type = method_info.get('type', 'digital')
                    
                    # Add emoji based on type
                    if method_type == 'crypto':
                        emoji = "₿"
                    elif method_type == 'traditional':
                        emoji = "🏦"
                    else:
                        emoji = "💳"
                    
                    callback_data = f"payment_info_{method_key.lower().replace(' ', '_')}"
                    keyboard.append([InlineKeyboardButton(f"{emoji} {method_name}", callback_data=callback_data)])
                    method_list += f"• {emoji} {method_name}\n"
        
        if not keyboard:
            # Fallback if no payment methods configured
            keyboard = [
                [InlineKeyboardButton("₿ Bitcoin", callback_data="payment_info_bitcoin")],
                [InlineKeyboardButton("💳 Bank Transfer", callback_data="payment_info_bank")],
                [InlineKeyboardButton("💰 PayPal", callback_data="payment_info_paypal")]
            ]
            method_list = "• ₿ Bitcoin (Recommended)\n• 💳 Bank Transfer\n• 💰 PayPal\n"
        
        keyboard.extend([
            [InlineKeyboardButton("⬅️ Back to Address", callback_data="confirm_address")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
        ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            f"📦 **Checkout Process - Step 5/5**\n\n"
            f"💳 **Choose Payment Method:**\n\n"
            f"💰 **Total Amount:** ${total:.2f}\n\n"
            f"Available payment methods:\n"
            f"{method_list}\n"
            f"Select your preferred payment method:",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    async def handle_payment_info(self, query, data):
        """Handle payment information display"""
        user_id = query.from_user.id
        payment_type = data.split("_")[2]  # Extract from "payment_info_bitcoin"
        
        # Get cart total
        cart = self.db.get_user_cart(user_id)
        total = 0
        for item in cart:
            product = self.db.get_product(item['product_id'])
            if product:
                total += product.price * item['quantity']
        
        # Load payment methods from admin dashboard
        payment_methods = self.db.get_payment_methods()
        
        # Find the matching payment method
        selected = None
        for method_key, method_info in payment_methods.items():
            if method_key.lower().replace(' ', '_') == payment_type or method_key.lower() == payment_type:
                selected = method_info
                break
        
        # Fallback to hardcoded if not found
        if not selected:
            fallback_info = {
                "bitcoin": {
                    "name": "Bitcoin",
                    "address": "bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq",
                    "qr_code": "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq",
                    "instructions": "1. Send exact amount to the address above\n2. Include your order reference in memo\n3. Contact operator with transaction ID"
                },
                "bank": {
                    "name": "Bank Transfer",
                    "address": "Account: 1234567890\nBank: Example Bank\nRouting: 987654321",
                    "qr_code": "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=Account:1234567890",
                    "instructions": "1. Transfer exact amount to account above\n2. Include your name in reference\n3. Contact operator with transfer receipt"
                },
                "paypal": {
                    "name": "PayPal",
                    "address": "payments@example.com",
                    "qr_code": "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=payments@example.com",
                    "instructions": "1. Send payment to email above\n2. Include order details in notes\n3. Contact operator with payment confirmation"
                }
            }
            selected = fallback_info.get(payment_type, fallback_info["bitcoin"])
        
        # Generate order reference
        import random
        order_ref = f"ORD{random.randint(10000, 99999)}"
        
        keyboard = [
            [InlineKeyboardButton("💬 Contact Operator", callback_data="contact_operator")],
            [InlineKeyboardButton("📋 Copy Address", callback_data=f"copy_{payment_type}")],
            [InlineKeyboardButton("⬅️ Back to Payment", callback_data="payment_bitcoin")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Format payment information using admin dashboard data
        payment_name = selected.get('name', 'Payment Method')
        payment_address = selected.get('wallet_address', selected.get('address', ''))
        payment_instructions = selected.get('instructions', '')
        qr_code_url = selected.get('qr_code_url', selected.get('qr_code', ''))
        
        # Create payment text
        payment_text = f"💳 **{payment_name} Payment**\n\n"
        payment_text += f"💰 **Amount:** ${total:.2f}\n"
        payment_text += f"📋 **Order Reference:** {order_ref}\n\n"
        
        if payment_address:
            payment_text += f"📍 **Payment Details:**\n"
            payment_text += f"`{payment_address}`\n\n"
        
        if qr_code_url:
            payment_text += f"📱 **QR Code:** [Click to View]({qr_code_url})\n\n"
        
        if payment_instructions:
            payment_text += f"📋 **Instructions:**\n{payment_instructions}\n\n"
        
        payment_text += f"⚠️ **Important:** Contact operator after payment confirmation."
        
        await query.edit_message_text(
            payment_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    async def handle_contact_operator(self, query):
        """Handle contact operator"""
        # Get operators from admin dashboard
        operators = self.db.get_operators()
        active_operators = [op for op in operators.values() if op.get('is_active', True)]
        
        keyboard = [
            [InlineKeyboardButton("✅ Confirm Payment Made", callback_data="confirm_payment")],
            [InlineKeyboardButton("⬅️ Back to Payment", callback_data="payment_bitcoin")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Build operator contact info with proper escaping
        operator_info = "👨‍💼 Contact Support Team\n\n"
        
        if active_operators:
            operator_info += "📞 Available Operators:\n"
            for op in active_operators:
                # Escape special characters that could break Markdown
                name = str(op['name']).replace('*', '\\*').replace('_', '\\_').replace('`', '\\`')
                operator_info += f"• {name}\n"
                
                if op.get('telegram_username'):
                    username = str(op['telegram_username']).replace('*', '\\*').replace('_', '\\_').replace('`', '\\`')
                    operator_info += f"  💬 Telegram: @{username}\n"
                    
                if op.get('email'):
                    email = str(op['email']).replace('*', '\\*').replace('_', '\\_').replace('`', '\\`')
                    operator_info += f"  📧 Email: {email}\n"
                    
                if op.get('phone'):
                    phone = str(op['phone']).replace('*', '\\*').replace('_', '\\_').replace('`', '\\`')
                    operator_info += f"  📱 Phone: {phone}\n"
                    
                if op.get('working_hours'):
                    hours = str(op['working_hours']).replace('*', '\\*').replace('_', '\\_').replace('`', '\\`')
                    operator_info += f"  ⏰ Hours: {hours}\n"
                    
                operator_info += "\n"
        else:
            operator_info += "💬 Telegram: @shopoperator\n"
            operator_info += "📧 Email: support@shopbot.com\n"
            operator_info += "⏰ Hours: 24/7 Support\n\n"
        
        operator_info += "📝 When contacting, please provide:\n"
        operator_info += "• Your order details\n"
        operator_info += "• Payment confirmation/transaction ID\n"
        operator_info += "• Delivery address\n"
        operator_info += "• Any questions or concerns\n\n"
        operator_info += "💳 After making payment, click confirm below:"
        
        await query.edit_message_text(
            operator_info,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
    
    async def handle_contact_support(self, query):
        """Handle contact support - shows operators from admin dashboard"""
        # Get operators from admin dashboard
        operators = self.db.get_operators()
        active_operators = [op for op in operators.values() if op.get('is_active', True)]
        
        keyboard = [
            [InlineKeyboardButton("⬅️ Back to Support", callback_data="cmd_operator")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Build operator contact info with proper escaping
        support_info = "📞 Customer Support Team\n\n"
        
        if active_operators:
            support_info += "👨‍💼 Available Support Operators:\n\n"
            for op in active_operators:
                # Escape special characters that could break Markdown
                name = str(op['name']).replace('*', '\\*').replace('_', '\\_').replace('`', '\\`')
                support_info += f"• {name}\n"
                
                if op.get('telegram_username'):
                    username = str(op['telegram_username']).replace('*', '\\*').replace('_', '\\_').replace('`', '\\`')
                    support_info += f"  💬 Telegram: @{username}\n"
                    
                if op.get('email'):
                    email = str(op['email']).replace('*', '\\*').replace('_', '\\_').replace('`', '\\`')
                    support_info += f"  📧 Email: {email}\n"
                    
                if op.get('phone'):
                    phone = str(op['phone']).replace('*', '\\*').replace('_', '\\_').replace('`', '\\`')
                    support_info += f"  📱 Phone: {phone}\n"
                    
                if op.get('working_hours'):
                    hours = str(op['working_hours']).replace('*', '\\*').replace('_', '\\_').replace('`', '\\`')
                    support_info += f"  ⏰ Hours: {hours}\n"
                    
                support_info += "\n"
                
            support_info += "💡 How to Contact:\n"
            support_info += "• Choose any operator above\n"
            support_info += "• Provide your order details\n"
            support_info += "• Be specific about your issue\n"
            support_info += "• Allow some time for response\n\n"
            support_info += "🔧 We can help with:\n"
            support_info += "• Order status and tracking\n"
            support_info += "• Payment issues\n"
            support_info += "• Product questions\n"
            support_info += "• Technical support\n"
            support_info += "• Returns and refunds"
        else:
            support_info += "💬 Default Support:\n"
            support_info += "Telegram: @shopoperator\n"
            support_info += "Email: support@shopbot.com\n"
            support_info += "Hours: 24/7 Support\n\n"
            support_info += "No operators are currently configured in the admin dashboard."
        
        await query.edit_message_text(
            support_info,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    async def handle_confirm_payment(self, query):
        """Handle payment confirmation"""
        user_id = query.from_user.id
        
        # Create order from cart
        order = self.db.create_order(user_id)
        
        if order:
            # Clear cart after successful order
            self.db.clear_user_cart(user_id)
            
            # Clear user state
            if user_id in self.user_states:
                del self.user_states[user_id]
            
            keyboard = [
                [InlineKeyboardButton("📦 View My Orders", callback_data="cmd_orders")],
                [InlineKeyboardButton("🛍️ Continue Shopping", callback_data="cmd_listings")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
            ]
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                f"✅ **Payment Confirmed Successfully!**\n\n"
                f"📋 **Order ID:** #{order.id}\n"
                f"💰 **Total:** ${order.total:.2f}\n"
                f"📅 **Date:** {order.created_at[:10]}\n"
                f"📦 **Status:** {order.status}\n\n"
                f"🚚 **What's Next:**\n"
                f"• Your order is being processed\n"
                f"• You'll receive shipping updates\n"
                f"• Expected delivery: 2-7 business days\n\n"
                f"📞 **Support:** Contact our support team for any questions\n\n"
                f"Thank you for your purchase!",
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
        else:
            keyboard = [
                [InlineKeyboardButton("🔄 Try Again", callback_data="confirm_payment")],
                [InlineKeyboardButton("⬅️ Back to Payment", callback_data="payment_bitcoin")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
            ]
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                "❌ **Order Creation Failed**\n\n"
                "There was an issue creating your order. Please try again or contact support.\n\n"
                "💬 **Support:** Contact our support team",
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
            
    async def handle_product_view(self, query, data):
        """Handle product view callback"""
        product_id = int(data.split("_")[1])
        product = self.db.get_product(product_id)
        
        if not product:
            await query.edit_message_text("❌ Product not found.")
            return
            
        keyboard = [
            [InlineKeyboardButton("🛒 Select Quantity & Add to Cart", callback_data=f"quantity_{product_id}")],
            [InlineKeyboardButton("💝 Add to Wishlist", callback_data=f"add_to_wishlist_{product_id}")],
            [InlineKeyboardButton("⭐ Rate Product", callback_data=f"rate_{product_id}")],
            [InlineKeyboardButton("⬅️ Back to Category", callback_data=f"category_{product.category}")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Create product display with image if available
        product_text = f"🛍️ **{product.name}**\n\n"
        if product.image_url:
            product_text += f"📸 [View Product Image]({product.image_url})\n\n"
        product_text += f"💰 **Price:** ${product.price:.2f} per gram\n"
        product_text += f"📦 **Available:** {product.stock}g in stock\n"
        product_text += f"⭐ **Rating:** {product.rating:.1f}/5.0\n"
        product_text += f"📂 **Category:** {product.category}\n\n"
        product_text += f"📝 **Description:**\n{product.description}"
        
        await query.edit_message_text(
            product_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    async def handle_add_to_cart(self, query, data):
        """Handle add to cart callback"""
        user_id = query.from_user.id
        product_id = int(data.split("_")[3])
        
        success = self.db.add_to_cart(user_id, product_id)
        
        if success:
            await query.edit_message_text("✅ Product added to cart!")
        else:
            await query.edit_message_text("❌ Failed to add product to cart.")
            
    async def handle_checkout(self, query):
        """Handle checkout callback"""
        user_id = query.from_user.id
        
        # Process checkout
        order = self.db.create_order(user_id)
        
        if order:
            await query.edit_message_text(
                f"✅ Order #{order.id} created successfully!\n\n"
                f"Total: ${order.total:.2f}\n"
                f"Status: {order.status}\n\n"
                f"You will receive updates about your order."
            )
        else:
            await query.edit_message_text("❌ Failed to create order. Please try again.")
            
    async def handle_vanish_setting(self, query, data):
        """Handle vanish time setting"""
        user_id = query.from_user.id
        time_setting = data.split("_")[1]
        
        if time_setting == "never":
            self.vanishing.set_user_vanish_time(user_id, 0)
            await query.edit_message_text("♾️ Messages will never vanish automatically.")
        else:
            seconds = int(time_setting)
            self.vanishing.set_user_vanish_time(user_id, seconds)
            await query.edit_message_text(f"⏰ Messages will vanish after {seconds} seconds.")
            
    async def handle_rating(self, query, data):
        """Handle product rating"""
        # Check if it's "rate_my_purchases" - redirect to appropriate handler
        if data == "rate_my_purchases":
            await self.handle_rate_my_purchases(query)
            return
            
        product_id = int(data.split("_")[1])
        user_id = query.from_user.id
        
        keyboard = [
            [InlineKeyboardButton("⭐", callback_data=f"rating_{product_id}_1")],
            [InlineKeyboardButton("⭐⭐", callback_data=f"rating_{product_id}_2")],
            [InlineKeyboardButton("⭐⭐⭐", callback_data=f"rating_{product_id}_3")],
            [InlineKeyboardButton("⭐⭐⭐⭐", callback_data=f"rating_{product_id}_4")],
            [InlineKeyboardButton("⭐⭐⭐⭐⭐", callback_data=f"rating_{product_id}_5")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            "⭐ Rate this product (1-5 stars):",
            reply_markup=reply_markup
        )
        
    async def handle_general_callback(self, query, data):
        """Handle general callbacks"""
        if data == "contact_support":
            await query.edit_message_text(
                "📞 **Contact Support**\n\n"
                "Send us a message and we'll get back to you:\n"
                "Email: support@vanishingshop.com\n"
                "Response time: 24 hours"
            )
        elif data == "faq":
            await query.edit_message_text(
                "❓ **Frequently Asked Questions**\n\n"
                "Q: How do vanishing messages work?\n"
                "A: Messages automatically delete after your set time period.\n\n"
                "Q: Can I cancel an order?\n"
                "A: Yes, contact support within 1 hour of placing the order.\n\n"
                "Q: How do I change my vanish settings?\n"
                "A: Use the /vanish command."
            )
            
    async def handle_admin_action(self, query, data):
        """Handle admin actions"""
        user_id = query.from_user.id
        
        if not self.db.is_admin(user_id):
            await query.edit_message_text("❌ Access denied.")
            return
            
        if data == "admin_products":
            await self.show_admin_products(query)
        elif data == "admin_orders":
            await self.show_admin_orders(query)
        elif data == "admin_users":
            await self.show_admin_users(query)
        elif data == "admin_stats":
            await self.show_admin_stats(query)
            
    async def show_admin_products(self, query):
        """Show admin product management"""
        products = self.db.get_products()
        
        if not products:
            await query.edit_message_text("📦 No products in database.")
            return
            
        product_text = "📦 **Product Management**\n\n"
        for product in products[:10]:
            product_text += f"• {product.name} - ${product.price:.2f} (Stock: {product.stock})\n"
            
        await query.edit_message_text(product_text, parse_mode='Markdown')
        
    async def show_admin_orders(self, query):
        """Show admin order management"""
        orders = self.db.get_all_orders()
        
        if not orders:
            await query.edit_message_text("📋 No orders found.")
            return
            
        order_text = "📋 **Order Management**\n\n"
        for order in orders[-10:]:
            order_text += f"Order #{order.id} - ${order.total:.2f} ({order.status})\n"
            
        await query.edit_message_text(order_text, parse_mode='Markdown')
        
    async def show_admin_users(self, query):
        """Show admin user management"""
        users = self.db.get_all_users()
        
        user_text = f"👥 **User Management**\n\nTotal users: {len(users)}\n\n"
        for user in users[-10:]:
            user_text += f"• {user.username} (ID: {user.id})\n"
            
        await query.edit_message_text(user_text, parse_mode='Markdown')
        
    async def show_admin_stats(self, query):
        """Show admin statistics"""
        stats = self.db.get_statistics()
        
        stats_text = "📊 **Statistics**\n\n"
        stats_text += f"👥 Total Users: {stats['total_users']}\n"
        stats_text += f"📦 Total Products: {stats['total_products']}\n"
        stats_text += f"📋 Total Orders: {stats['total_orders']}\n"
        stats_text += f"💰 Total Revenue: ${stats['total_revenue']:.2f}\n"
        
        await query.edit_message_text(stats_text, parse_mode='Markdown')
        
    async def handle_remove_from_cart(self, query, data):
        """Handle remove from cart callback"""
        user_id = query.from_user.id
        product_id = int(data.split("_")[2])  # Extract from "remove_cart_1"
        
        success = self.db.remove_from_cart(user_id, product_id)
        
        if success:
            # Return to cart view
            await self.handle_cart_from_button(query)
        else:
            await query.edit_message_text("❌ Failed to remove item from cart.")
            
    async def handle_remove_from_wishlist(self, query, data):
        """Handle remove from wishlist callback"""
        user_id = query.from_user.id
        product_id = int(data.split("_")[2])  # Extract from "remove_wishlist_1"
        
        success = self.db.remove_from_wishlist(user_id, product_id)
        
        if success:
            # Return to wishlist view
            await self.handle_wishlist_from_button(query)
        else:
            await query.edit_message_text("❌ Failed to remove item from wishlist.")
            
    async def handle_clear_cart(self, query):
        """Handle clear cart callback"""
        user_id = query.from_user.id
        
        success = self.db.clear_user_cart(user_id)
        
        if success:
            keyboard = [
                [InlineKeyboardButton("🛍️ Continue Shopping", callback_data="cmd_listings")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                "🛒 **Cart Cleared Successfully!**\n\n"
                "Your cart is now empty. Continue shopping to add new items.",
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
        else:
            await query.edit_message_text("❌ Failed to clear cart.")
        
    async def unknown_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle unknown commands"""
        user_id = update.effective_user.id
        
        message = await update.message.reply_text(
            "❓ Unknown command. Use /help to see available commands."
        )
        await self.vanishing.schedule_deletion(message, user_id)
        


    async def handle_text(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle text messages"""
        user_id = update.effective_user.id
        text = update.message.text
        
        # Check if user is entering address
        if user_id in self.user_states and self.user_states[user_id] == "entering_address":
            # Store the address and proceed to confirmation
            self.user_states[user_id] = {"state": "address_entered", "address": text}
            
            keyboard = [
                [InlineKeyboardButton("✅ Confirm Address", callback_data="confirm_address")],
                [InlineKeyboardButton("📝 Edit Address", callback_data="enter_address")],
                [InlineKeyboardButton("⬅️ Back to Delivery", callback_data="start_checkout")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
            ]
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            message = await update.message.reply_text(
                f"📦 **Checkout Process - Step 4/5**\n\n"
                f"📍 **Address Entered:**\n\n"
                f"{text}\n\n"
                f"✅ Does this address look correct?\n"
                f"Proceed to payment method selection:",
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
            await self.vanishing.schedule_deletion(message, user_id)
        else:
            # Default text message handler
            message = await update.message.reply_text(
                "💬 I understand text messages, but I work with commands.\n"
                "Use /help to see what I can do!"
            )
            await self.vanishing.schedule_deletion(message, user_id)
    
    async def handle_rating_submission(self, query, data):
        """Handle rating submission"""
        user_id = query.from_user.id
        
        # Parse data: rating_productid_starvalue
        parts = data.split("_")
        product_id = int(parts[1])
        rating_value = int(parts[2])
        
        # Get product details
        product = self.db.get_product(product_id)
        if not product:
            await query.edit_message_text("❌ Product not found.")
            return
        
        # Save the rating
        success = self.db.add_product_rating(product_id, user_id, rating_value)
        
        if success:
            # Get star display
            star_display = "⭐" * rating_value
            
            keyboard = [
                [InlineKeyboardButton("📊 View Weekly Ratings", callback_data="cmd_rating")],
                [InlineKeyboardButton("⭐ Rate Another Product", callback_data="rate_my_purchases")],
                [InlineKeyboardButton("🛍️ Continue Shopping", callback_data="cmd_listings")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
            ]
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                f"✅ **Rating Submitted Successfully!**\n\n"
                f"📦 **Product:** {product.name}\n"
                f"⭐ **Your Rating:** {star_display} ({rating_value}/5)\n\n"
                f"Thank you for your feedback! Your rating helps other customers make informed decisions.",
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
        else:
            keyboard = [
                [InlineKeyboardButton("🔄 Try Again", callback_data=f"rate_{product_id}")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_menu")]
            ]
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                "❌ **Rating Failed**\n\n"
                "There was an issue saving your rating. Please try again.",
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
