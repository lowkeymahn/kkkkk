"""
Vanishing messages functionality
"""
import asyncio
import logging
from typing import Dict, Optional
from telegram import Message
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class VanishingMessages:
    def __init__(self):
        self.user_vanish_times: Dict[int, int] = {}  # user_id -> seconds
        self.scheduled_deletions: Dict[str, asyncio.Task] = {}
        self.default_vanish_time = 300  # 5 minutes default
        
    def get_user_vanish_time(self, user_id: int) -> int:
        """Get vanish time for a user"""
        return self.user_vanish_times.get(user_id, self.default_vanish_time)
        
    def set_user_vanish_time(self, user_id: int, seconds: int):
        """Set vanish time for a user"""
        self.user_vanish_times[user_id] = seconds
        logger.info(f"Set vanish time for user {user_id}: {seconds} seconds")
        
    async def schedule_deletion(self, message: Message, user_id: int):
        """Schedule a message for deletion"""
        vanish_time = self.get_user_vanish_time(user_id)
        
        # If vanish time is 0, don't schedule deletion
        if vanish_time == 0:
            return
            
        # Create unique key for this message
        message_key = f"{message.chat_id}_{message.message_id}"
        
        # Cancel existing task if it exists
        if message_key in self.scheduled_deletions:
            self.scheduled_deletions[message_key].cancel()
            
        # Schedule new deletion
        task = asyncio.create_task(
            self._delete_after_delay(message, vanish_time)
        )
        self.scheduled_deletions[message_key] = task
        
        logger.info(f"Scheduled deletion for message {message_key} in {vanish_time} seconds")
        
    async def _delete_after_delay(self, message: Message, delay: int):
        """Delete message after specified delay"""
        try:
            await asyncio.sleep(delay)
            await message.delete()
            
            # Remove from scheduled deletions
            message_key = f"{message.chat_id}_{message.message_id}"
            if message_key in self.scheduled_deletions:
                del self.scheduled_deletions[message_key]
                
            logger.info(f"Deleted message {message_key} after {delay} seconds")
            
        except asyncio.CancelledError:
            logger.info(f"Deletion cancelled for message {message.message_id}")
        except Exception as e:
            logger.error(f"Error deleting message {message.message_id}: {e}")
            
    async def cancel_deletion(self, message: Message):
        """Cancel scheduled deletion for a message"""
        message_key = f"{message.chat_id}_{message.message_id}"
        
        if message_key in self.scheduled_deletions:
            self.scheduled_deletions[message_key].cancel()
            del self.scheduled_deletions[message_key]
            logger.info(f"Cancelled deletion for message {message_key}")
            
    def get_scheduled_count(self) -> int:
        """Get number of scheduled deletions"""
        return len(self.scheduled_deletions)
        
    async def cleanup_expired_tasks(self):
        """Clean up expired or completed tasks"""
        expired_keys = []
        
        for key, task in self.scheduled_deletions.items():
            if task.done():
                expired_keys.append(key)
                
        for key in expired_keys:
            del self.scheduled_deletions[key]
            
        logger.info(f"Cleaned up {len(expired_keys)} expired tasks")
        
    def get_user_settings_summary(self, user_id: int) -> str:
        """Get summary of user's vanishing settings"""
        vanish_time = self.get_user_vanish_time(user_id)
        
        if vanish_time == 0:
            return "Messages never vanish"
        elif vanish_time < 60:
            return f"Messages vanish after {vanish_time} seconds"
        elif vanish_time < 3600:
            minutes = vanish_time // 60
            return f"Messages vanish after {minutes} minute{'s' if minutes != 1 else ''}"
        else:
            hours = vanish_time // 3600
            return f"Messages vanish after {hours} hour{'s' if hours != 1 else ''}"
            
    def get_vanish_time_options(self) -> Dict[str, int]:
        """Get available vanish time options"""
        return {
            "30 seconds": 30,
            "1 minute": 60,
            "5 minutes": 300,
            "10 minutes": 600,
            "1 hour": 3600,
            "Never": 0
        }