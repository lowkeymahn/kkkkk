"""
Bot command implementations
"""
import logging
from data.models import Product, Order, User
from datetime import datetime

logger = logging.getLogger(__name__)

class BotCommands:
    def __init__(self, database):
        self.db = database
        
    def add_product(self, name, price, description, stock=100):
        """Add a new product to the database"""
        try:
            product = Product(
                id=self.db.get_next_product_id(),
                name=name,
                price=float(price),
                description=description,
                stock=int(stock)
            )
            return self.db.save_product(product)
        except Exception as e:
            logger.error(f"Error adding product: {e}")
            return False
            
    def get_product_details(self, product_id):
        """Get detailed information about a product"""
        try:
            product = self.db.get_product(product_id)
            if not product:
                return None
                
            ratings = self.db.get_product_ratings(product_id)
            avg_rating = sum(ratings) / len(ratings) if ratings else 0
            
            return {
                'product': product,
                'average_rating': avg_rating,
                'total_ratings': len(ratings),
                'ratings': ratings
            }
        except Exception as e:
            logger.error(f"Error getting product details: {e}")
            return None
            
    def search_products(self, query):
        """Search for products by name or description"""
        try:
            products = self.db.get_products()
            results = []
            
            query_lower = query.lower()
            for product in products:
                if (query_lower in product.name.lower() or 
                    query_lower in product.description.lower()):
                    results.append(product)
                    
            return results
        except Exception as e:
            logger.error(f"Error searching products: {e}")
            return []
            
    def calculate_cart_total(self, user_id):
        """Calculate total price of items in user's cart"""
        try:
            cart = self.db.get_user_cart(user_id)
            total = 0
            
            for item in cart:
                product = self.db.get_product(item['product_id'])
                if product:
                    total += product.price * item['quantity']
                    
            return total
        except Exception as e:
            logger.error(f"Error calculating cart total: {e}")
            return 0
            
    def process_order(self, user_id):
        """Process an order from user's cart"""
        try:
            cart = self.db.get_user_cart(user_id)
            if not cart:
                return None
                
            # Calculate total
            total = self.calculate_cart_total(user_id)
            
            # Create order
            order = Order(
                id=self.db.get_next_order_id(),
                user_id=user_id,
                items=cart,
                total=total,
                status="pending",
                created_at=datetime.now().isoformat()
            )
            
            # Save order and clear cart
            if self.db.save_order(order):
                self.db.clear_user_cart(user_id)
                
                # Update stock
                for item in cart:
                    product = self.db.get_product(item['product_id'])
                    if product:
                        product.stock -= item['quantity']
                        self.db.save_product(product)
                        
                return order
            
            return None
        except Exception as e:
            logger.error(f"Error processing order: {e}")
            return None
            
    def add_rating(self, user_id, product_id, rating):
        """Add a rating for a product"""
        try:
            # Check if user has purchased this product
            orders = self.db.get_user_orders(user_id)
            has_purchased = False
            
            for order in orders:
                if order.status == "completed":
                    for item in order.items:
                        if item['product_id'] == product_id:
                            has_purchased = True
                            break
                            
            if not has_purchased:
                return False, "You can only rate products you have purchased."
                
            # Add rating
            success = self.db.add_product_rating(product_id, user_id, rating)
            
            if success:
                # Update product average rating
                self.update_product_rating(product_id)
                return True, "Rating added successfully!"
            else:
                return False, "Failed to add rating."
                
        except Exception as e:
            logger.error(f"Error adding rating: {e}")
            return False, "Error adding rating."
            
    def update_product_rating(self, product_id):
        """Update the average rating for a product"""
        try:
            ratings = self.db.get_product_ratings(product_id)
            if ratings:
                avg_rating = sum(ratings) / len(ratings)
                product = self.db.get_product(product_id)
                if product:
                    product.rating = avg_rating
                    self.db.save_product(product)
        except Exception as e:
            logger.error(f"Error updating product rating: {e}")
            
    def get_user_statistics(self, user_id):
        """Get statistics for a user"""
        try:
            orders = self.db.get_user_orders(user_id)
            cart = self.db.get_user_cart(user_id)
            wishlist = self.db.get_user_wishlist(user_id)
            
            total_spent = sum(order.total for order in orders if order.status == "completed")
            
            return {
                'total_orders': len(orders),
                'total_spent': total_spent,
                'cart_items': len(cart),
                'wishlist_items': len(wishlist),
                'pending_orders': len([o for o in orders if o.status == "pending"])
            }
        except Exception as e:
            logger.error(f"Error getting user statistics: {e}")
            return {}
            
    def get_popular_products(self, limit=5):
        """Get most popular products based on orders"""
        try:
            orders = self.db.get_all_orders()
            product_counts = {}
            
            for order in orders:
                for item in order.items:
                    product_id = item['product_id']
                    quantity = item['quantity']
                    product_counts[product_id] = product_counts.get(product_id, 0) + quantity
                    
            # Sort by popularity
            sorted_products = sorted(product_counts.items(), key=lambda x: x[1], reverse=True)
            
            popular_products = []
            for product_id, count in sorted_products[:limit]:
                product = self.db.get_product(product_id)
                if product:
                    popular_products.append({
                        'product': product,
                        'order_count': count
                    })
                    
            return popular_products
        except Exception as e:
            logger.error(f"Error getting popular products: {e}")
            return []
            
    def update_order_status(self, order_id, new_status):
        """Update order status"""
        try:
            order = self.db.get_order(order_id)
            if order:
                order.status = new_status
                return self.db.save_order(order)
            return False
        except Exception as e:
            logger.error(f"Error updating order status: {e}")
            return False
            
    def get_low_stock_products(self, threshold=10):
        """Get products with low stock"""
        try:
            products = self.db.get_products()
            low_stock = [p for p in products if p.stock <= threshold]
            return low_stock
        except Exception as e:
            logger.error(f"Error getting low stock products: {e}")
            return []