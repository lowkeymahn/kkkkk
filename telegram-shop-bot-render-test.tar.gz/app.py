#!/usr/bin/env python3
"""
Unified application entry point for Railway deployment
Combines admin dashboard and telegram bot into single process
"""
import os
import threading
import asyncio
from admin_dashboard import app as admin_app
from main import main as run_bot

def run_admin_dashboard():
    """Run the admin dashboard"""
    port = int(os.environ.get("PORT", 5000))
    admin_app.run(host='0.0.0.0', port=port, debug=False)

def run_telegram_bot():
    """Run the telegram bot"""
    asyncio.run(run_bot())

if __name__ == '__main__':
    # Start admin dashboard in a separate thread
    admin_thread = threading.Thread(target=run_admin_dashboard, daemon=True)
    admin_thread.start()
    
    # Run telegram bot in main thread
    run_telegram_bot()